// Système de navigation des menus avec support des nouveaux modes

// Variables globales pour les menus
let currentMenuSection = 'play';
let selectedGameMode = 'competitive';
let selectedMap = 'dust2';
let selectedWeaponCategory = 'rifles';

// Initialisation des menus
document.addEventListener('DOMContentLoaded', () => {
    loadWeapons();
    setupMenuEventListeners();
    setupSettingsListeners();
});

// Configuration des écouteurs d'événements
function setupMenuEventListeners() {
    // Navigation du menu principal
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const section = e.target.closest('.nav-btn').getAttribute('onclick').match(/'(.+)'/)[1];
            showMenuSection(section);
        });
    });

    // Sliders de paramètres
    document.querySelectorAll('input[type="range"]').forEach(slider => {
        slider.addEventListener('input', updateSliderDisplay);
    });
}

// Affichage des sections de menu
function showMenuSection(section) {
    // Cacher toutes les sections
    document.querySelectorAll('.menu-section').forEach(sec => {
        sec.classList.add('hidden');
    });
    
    // Retirer la classe active de tous les boutons de navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Afficher la section sélectionnée
    document.getElementById(`${section}-section`).classList.remove('hidden');
    
    // Activer le bouton correspondant
    document.querySelector(`.nav-btn[onclick*="${section}"]`).classList.add('active');
    
    currentMenuSection = section;
    
    // Actions spécifiques selon la section
    switch(section) {
        case 'friends':
            loadFriends();
            break;
        case 'arsenal':
            loadWeapons();
            break;
        case 'leaderboard':
            switchLeaderboardTab('competitive');
            break;
        case 'settings':
            loadCurrentSettings();
            break;
    }
}

// Sélection du mode de jeu
function selectGameMode(mode) {
    // Retirer la sélection précédente
    document.querySelectorAll('.game-mode').forEach(modeEl => {
        modeEl.classList.remove('selected');
    });
    
    // Sélectionner le nouveau mode
    event.target.closest('.game-mode').classList.add('selected');
    selectedGameMode = mode;
    
    // Mettre à jour l'interface selon le mode
    updateModeSpecificUI(mode);
    
    console.log('Mode de jeu sélectionné:', mode);
}

// Mise à jour de l'interface selon le mode
function updateModeSpecificUI(mode) {
    const mapSelection = document.querySelector('.map-selection');
    const playSettings = document.querySelector('.play-settings');
    
    // Afficher/masquer les options selon le mode
    if (mode === 'deathmatch') {
        // Pour le deathmatch, masquer certaines options
        if (playSettings) {
            playSettings.style.opacity = '0.7';
        }
    } else {
        if (playSettings) {
            playSettings.style.opacity = '1';
        }
    }
    
    // Mettre à jour le texte du bouton
    const launchBtn = document.querySelector('.launch-game-btn');
    if (launchBtn) {
        // Utiliser les modes de jeu locaux si MatchmakingSystem n'est pas disponible
        const modes = window.MatchmakingSystem?.gameModes || gameModes || {
            duel: { name: 'Duel' },
            competitive: { name: 'Compétitif' },
            unrated: { name: 'Non classé' },
            deathmatch: { name: 'Deathmatch' }
        };
        
        const modeData = modes[mode];
        if (modeData) {
            launchBtn.innerHTML = `<i class="fas fa-rocket"></i> RECHERCHER ${modeData.name.toUpperCase()}`;
        }
    }
}

// Sélection de la carte
function selectMap(map) {
    // Retirer la sélection précédente
    document.querySelectorAll('.map-card').forEach(mapEl => {
        mapEl.classList.remove('active');
    });
    
    // Sélectionner la nouvelle carte
    event.target.closest('.map-card').classList.add('active');
    selectedMap = map;
    
    console.log('Carte sélectionnée:', map);
}

// Lancement du jeu avec nouveau système de matchmaking
async function launchGame() {
    const launchBtn = document.querySelector('.launch-game-btn');
    
    if (!currentUser) {
        showMessage('Vous devez être connecté pour jouer', 'error');
        return;
    }
    
    try {
        // Animation du bouton
        launchBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> RECHERCHE EN COURS...';
        launchBtn.disabled = true;
        
        // Récupérer les préférences
        const region = document.getElementById('region-select')?.value || 'EU';
        const maxPing = parseInt(document.getElementById('ping-select')?.value) || 100;
        
        const options = {
            region: region,
            maxPing: maxPing
        };
        
        console.log('Lancement du matchmaking:', {
            mode: selectedGameMode,
            map: selectedMap === 'auto' ? null : selectedMap,
            options: options
        });
        
        // Utiliser le nouveau système de matchmaking
        const queueId = await MatchmakingSystem.findMatch(
            selectedGameMode, 
            selectedMap === 'auto' ? null : selectedMap, 
            options
        );
        
        if (queueId) {
            console.log('Rejoint la file d\'attente:', queueId);
            // L'interface de matchmaking s'affiche automatiquement
        }
        
    } catch (error) {
        console.error('Erreur lors du lancement:', error);
        launchBtn.innerHTML = '<i class="fas fa-exclamation-triangle"></i> ERREUR';
        showMessage(error.message || 'Impossible de lancer la partie', 'error');
        
        // Restaurer le bouton après 3 secondes
        setTimeout(() => {
            const modeData = MatchmakingSystem.gameModes[selectedGameMode];
            launchBtn.innerHTML = `<i class="fas fa-rocket"></i> RECHERCHER ${modeData.name.toUpperCase()}`;
            launchBtn.disabled = false;
        }, 3000);
    }
}

// Gestion du système d'amis amélioré
async function addFriend() {
    const usernameInput = document.getElementById('friend-username');
    const username = usernameInput.value.trim();
    
    if (!username) {
        showMessage('Veuillez entrer un nom d\'utilisateur', 'error');
        return;
    }
    
    if (username.length < 3 || username.length > 20) {
        showMessage('Le nom doit contenir entre 3 et 20 caractères', 'error');
        return;
    }
    
    if (!currentUser) {
        showMessage('Vous devez être connecté', 'error');
        return;
    }
    
    try {
        // Rechercher l'utilisateur dans la base de données
        const usersRef = database.ref('users');
        const snapshot = await usersRef.orderByChild('displayName').equalTo(username).once('value');
        
        if (!snapshot.exists()) {
            showMessage('Utilisateur introuvable', 'error');
            return;
        }
        
        const userData = Object.values(snapshot.val())[0];
        const friendId = Object.keys(snapshot.val())[0];
        
        if (friendId === currentUser.uid) {
            showMessage('Vous ne pouvez pas vous ajouter vous-même', 'error');
            return;
        }
        
        // Vérifier les paramètres de confidentialité
        const privacy = userData.privacy || {};
        if (privacy.allowFriendRequests === false) {
            showMessage('Cet utilisateur n\'accepte pas les demandes d\'amis', 'error');
            return;
        }
        
        // Vérifier si l'ami n'est pas déjà ajouté
        const currentUserRef = database.ref(`users/${currentUser.uid}/friends/${friendId}`);
        const existingFriend = await currentUserRef.once('value');
        
        if (existingFriend.exists()) {
            showMessage('Cet utilisateur est déjà dans votre liste d\'amis', 'error');
            return;
        }
        
        // Ajouter l'ami
        const friendPayload = {
            displayName: userData.displayName,
            avatar: userData.avatar || 'user',
            status: userData.status || 'offline',
            addedAt: firebase.database.ServerValue.TIMESTAMP
        };

        await currentUserRef.set(friendPayload);
        
        // Ajouter réciproquement
        await database.ref(`users/${friendId}/friends/${currentUser.uid}`).set({
            displayName: currentUser.displayName || currentUser.email.split('@')[0],
            avatar: 'user',
            status: 'online',
            addedAt: firebase.database.ServerValue.TIMESTAMP
        });
        
        showMessage('Ami ajouté avec succès !', 'success');
        usernameInput.value = '';
        loadFriends();
        
    } catch (error) {
        console.error('Erreur lors de l\'ajout d\'ami:', error);
        showMessage('Erreur lors de l\'ajout de l\'ami', 'error');
    }
}

// Recherche d'amis
function searchFriends(searchTerm) {
    const friendCards = document.querySelectorAll('.friend-card');
    
    friendCards.forEach(card => {
        const friendName = card.querySelector('.friend-name').textContent.toLowerCase();
        const shouldShow = friendName.includes(searchTerm.toLowerCase());
        card.style.display = shouldShow ? 'flex' : 'none';
    });
}

// Chargement de la liste d'amis amélioré
async function loadFriends() {
    if (!currentUser) return;
    
    const friendsList = document.getElementById('friends-list');
    
    try {
        const friendsRef = database.ref(`users/${currentUser.uid}/friends`);
        const snapshot = await friendsRef.once('value');
        
        friendsList.innerHTML = '';
        
        if (!snapshot.exists()) {
            friendsList.innerHTML = `
                <div class="no-friends">
                    <i class="fas fa-user-friends" style="font-size: 48px; color: rgba(255,255,255,0.3); margin-bottom: 20px;"></i>
                    <p style="color: rgba(255,255,255,0.7);">Aucun ami pour le moment</p>
                    <p style="color: rgba(255,255,255,0.5); font-size: 14px;">Ajoutez des amis pour jouer ensemble !</p>
                </div>
            `;
            return;
        }
        
        const friends = snapshot.val();
        
        // Récupérer le statut en temps réel des amis
        for (const friendId of Object.keys(friends)) {
            const friend = friends[friendId];
            
            // Écouter les changements de statut
            database.ref(`users/${friendId}/status`).on('value', (statusSnapshot) => {
                const status = statusSnapshot.val() || 'offline';
                updateFriendStatus(friendId, status);
            });
            
            createFriendCard(friendId, friend);
        }
        
    } catch (error) {
        console.error('Erreur lors du chargement des amis:', error);
        friendsList.innerHTML = '<p style="color: #ef4444;">Erreur lors du chargement des amis</p>';
    }
}

// Création d'une carte d'ami améliorée
function createFriendCard(friendId, friendData) {
    const friendsList = document.getElementById('friends-list');
    
    const friendCard = document.createElement('div');
    friendCard.className = 'friend-card';
    friendCard.id = `friend-${friendId}`;
    
    friendCard.innerHTML = `
        <div class="friend-avatar">
            <i class="fas fa-${friendData.avatar || 'user'}"></i>
        </div>
        <div class="friend-info">
            <div class="friend-name">${friendData.displayName}</div>
            <div class="friend-status ${friendData.status || 'offline'}" id="status-${friendId}">
                <i class="fas fa-circle"></i> ${getStatusText(friendData.status || 'offline')}
            </div>
        </div>
        <div class="friend-actions">
            <button onclick="openProfileModal('${friendId}')" class="profile-btn" title="Voir le profil">
                <i class="fas fa-user"></i>
            </button>
            <button onclick="inviteFriend('${friendId}')" class="invite-btn" ${(friendData.status || 'offline') !== 'online' ? 'disabled' : ''} title="Inviter en partie">
                <i class="fas fa-gamepad"></i>
            </button>
            <button onclick="removeFriend('${friendId}')" class="remove-btn" title="Supprimer ami">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    friendsList.appendChild(friendCard);
}

// Mise à jour du statut d'un ami
function updateFriendStatus(friendId, status) {
    const statusElement = document.getElementById(`status-${friendId}`);
    if (statusElement) {
        statusElement.className = `friend-status ${status}`;
        statusElement.innerHTML = `<i class="fas fa-circle"></i> ${getStatusText(status)}`;
    }
    
    // Activer/désactiver le bouton d'invitation
    const inviteButton = document.querySelector(`#friend-${friendId} .invite-btn`);
    if (inviteButton) {
        inviteButton.disabled = status !== 'online';
    }
}

// Obtenir le texte du statut
function getStatusText(status) {
    switch(status) {
        case 'online': return 'En ligne';
        case 'playing': return 'En partie';
        case 'away': return 'Absent';
        default: return 'Hors ligne';
    }
}

// Invitation d'un ami avec support des nouveaux modes
async function inviteFriend(friendId) {
    if (!currentUser) return;
    
    try {
        // Vérifier si l'utilisateur est en ligne
        const friendRef = database.ref(`users/${friendId}/status`);
        const statusSnapshot = await friendRef.once('value');
        const status = statusSnapshot.val();
        
        if (status !== 'online') {
            showMessage('Cet ami n\'est pas en ligne', 'error');
            return;
        }
        
        // Créer une invitation de partie avec le mode sélectionné
        const invitationRef = database.ref(`users/${friendId}/invitations`).push();
        await invitationRef.set({
            from: currentUser.uid,
            fromName: currentUser.displayName || currentUser.email.split('@')[0],
            type: 'game_invite',
            gameMode: selectedGameMode,
            map: selectedMap === 'auto' ? null : selectedMap,
            timestamp: firebase.database.ServerValue.TIMESTAMP
        });
        
        showMessage('Invitation envoyée !', 'success');
        
    } catch (error) {
        console.error('Erreur invitation ami:', error);
        showMessage('Erreur lors de l\'envoi de l\'invitation', 'error');
    }
}

// Suppression d'un ami
async function removeFriend(friendId) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cet ami ?')) return;
    
    try {
        // Supprimer de ma liste
        await database.ref(`users/${currentUser.uid}/friends/${friendId}`).remove();
        
        // Supprimer de sa liste
        await database.ref(`users/${friendId}/friends/${currentUser.uid}`).remove();
        
        // Arrêter d'écouter les changements de statut
        database.ref(`users/${friendId}/status`).off();
        
        showMessage('Ami supprimé', 'success');
        loadFriends();
        
    } catch (error) {
        console.error('Erreur lors de la suppression:', error);
        showMessage('Erreur lors de la suppression', 'error');
    }
}

// Gestion de l'arsenal mis à jour
function showWeaponCategory(category) {
    // Retirer la sélection précédente
    document.querySelectorAll('.weapon-cat').forEach(cat => {
        cat.classList.remove('active');
    });
    
    // Sélectionner la nouvelle catégorie
    event.target.classList.add('active');
    selectedWeaponCategory = category;
    
    loadWeapons();
}

// Chargement des armes avec les nouvelles données
function loadWeapons() {
    const weaponsGrid = document.getElementById('weapons-grid');
    
    // Utiliser les données d'armes du gameplay.js
    const categoryWeapons = weapons[selectedWeaponCategory] || {};
    
    weaponsGrid.innerHTML = '';
    
    Object.entries(categoryWeapons).forEach(([weaponName, weaponStats]) => {
        const weaponCard = document.createElement('div');
        weaponCard.className = 'weapon-card';
        weaponCard.innerHTML = `
            <div class="weapon-icon">
                <i class="fas fa-crosshairs"></i>
            </div>
            <div class="weapon-name">${weaponName}</div>
            <div class="weapon-stats">
                <div class="weapon-stat">
                    <div class="stat-label">Dégâts</div>
                    <div class="stat-value">${weaponStats.damage}</div>
                </div>
                <div class="weapon-stat">
                    <div class="stat-label">Cadence</div>
                    <div class="stat-value">${weaponStats.fireRate}</div>
                </div>
                <div class="weapon-stat">
                    <div class="stat-label">Précision</div>
                    <div class="stat-value">${weaponStats.accuracy}%</div>
                </div>
                <div class="weapon-stat">
                    <div class="stat-label">Prix</div>
                    <div class="stat-value">$${weaponStats.price}</div>
                </div>
            </div>
            <div class="weapon-details">
                <div class="weapon-detail">
                    <span>Munitions: ${weaponStats.ammo}/${weaponStats.totalAmmo}</span>
                </div>
                <div class="weapon-detail">
                    <span>Pénétration: ${weaponStats.penetration}</span>
                </div>
            </div>
        `;
        
        weaponCard.addEventListener('click', () => selectWeapon(weaponName, weaponStats));
        weaponsGrid.appendChild(weaponCard);
    });
}

// Sélection d'une arme
function selectWeapon(weaponName, weaponStats) {
    console.log('Arme sélectionnée:', weaponName, weaponStats);
    
    // Retirer la sélection précédente
    document.querySelectorAll('.weapon-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Sélectionner la nouvelle arme
    event.target.closest('.weapon-card').classList.add('selected');
    
    // Afficher les détails de l'arme
    showWeaponDetails(weaponName, weaponStats);
}

// Affichage des détails de l'arme
function showWeaponDetails(weaponName, weaponStats) {
    const message = `
        ${weaponName} sélectionné
        
        Dégâts: ${weaponStats.damage}
        Cadence de tir: ${weaponStats.fireRate}
        Précision: ${weaponStats.accuracy}%
        Prix: $${weaponStats.price}
    `;
    
    showMessage(message, 'info');
}

// Gestion des classements mis à jour
function switchLeaderboardTab(type) {
    currentLeaderboardType = type;
    
    // Mettre à jour l'interface
    document.querySelectorAll('.leaderboard-tab').forEach(tab => tab.classList.remove('active'));
    document.querySelector(`[onclick*="${type}"]`).classList.add('active');
    
    // Charger les données
    loadLeaderboard(type);
}

// Chargement du classement avec support des nouveaux modes
async function loadLeaderboard(type) {
    const content = document.getElementById('leaderboard-content');
    content.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Chargement du classement...</div>';
    
    try {
        // Récupérer tous les utilisateurs avec leurs statistiques
        const usersRef = database.ref('users');
        const snapshot = await usersRef.once('value');
        const users = snapshot.val() || {};
        
        let sortedUsers = [];
        
        if (type === 'competitive' || type === 'duel') {
            // Classement par mode spécifique (utiliser le MMR)
            sortedUsers = Object.entries(users)
                .filter(([id, data]) => {
                    const privacy = data.privacy || {};
                    return (privacy.publicStats !== false) && data.stats;
                })
                .map(([id, data]) => {
                    const rank = data.rank || 'Fer I';
                    const mmr = calculateMMR(data);
                    
                    return {
                        id,
                        name: data.displayName || 'Joueur',
                        avatar: data.avatar || 'user',
                        rank: rank,
                        level: data.level || 1,
                        value: mmr,
                        status: data.status || 'offline',
                        stats: data.stats
                    };
                })
                .sort((a, b) => b.value - a.value)
                .slice(0, 100);
        } else {
            // Classements généraux (kills, level, etc.)
            sortedUsers = Object.entries(users)
                .filter(([id, data]) => {
                    const privacy = data.privacy || {};
                    return (privacy.publicStats !== false) && data.stats;
                })
                .map(([id, data]) => ({
                    id,
                    name: data.displayName || 'Joueur',
                    avatar: data.avatar || 'user',
                    rank: data.rank || 'Fer I',
                    level: data.level || 1,
                    value: getLeaderboardValue(data.stats || {}, type),
                    status: data.status || 'offline'
                }))
                .sort((a, b) => b.value - a.value)
                .slice(0, 100);
        }
        
        // Afficher le classement
        content.innerHTML = '';
        
        if (sortedUsers.length === 0) {
            content.innerHTML = '<div class="no-data">Aucune donnée disponible pour ce classement</div>';
            return;
        }
        
        sortedUsers.forEach((user, index) => {
            const playerElement = document.createElement('div');
            playerElement.className = `leaderboard-entry ${user.id === currentUser?.uid ? 'current-user' : ''}`;
            playerElement.onclick = () => openProfileModal(user.id);
            
            // Icône spéciale pour le podium
            let rankDisplay;
            if (index === 0) {
                rankDisplay = '<i class="fas fa-crown rank-1"></i>';
            } else if (index === 1) {
                rankDisplay = '<i class="fas fa-medal rank-2"></i>';
            } else if (index === 2) {
                rankDisplay = '<i class="fas fa-medal rank-3"></i>';
            } else {
                rankDisplay = `#${index + 1}`;
            }
            
            playerElement.innerHTML = `
                <div class="rank-position">${rankDisplay}</div>
                <div class="player-avatar">
                    <i class="fas fa-${user.avatar}"></i>
                    <div class="player-status ${user.status}"></div>
                </div>
                <div class="player-info">
                    <div class="player-name">${user.name}</div>
                    <div class="player-rank">${user.rank} (Niv. ${user.level})</div>
                </div>
                <div class="player-value">${formatLeaderboardValue(user.value, type)}</div>
            `;
            
            content.appendChild(playerElement);
        });
        
    } catch (error) {
        console.error('Erreur chargement classement:', error);
        content.innerHTML = '<div class="error">Erreur lors du chargement du classement</div>';
    }
}

// Calculer le MMR d'un joueur (similaire au matchmaking)
function calculateMMR(playerData) {
    const rank = playerData.rank || 'Fer I';
    const rankSystem = {
        'Fer I': 0, 'Fer II': 100, 'Fer III': 200,
        'Bronze I': 300, 'Bronze II': 400, 'Bronze III': 500,
        'Argent I': 600, 'Argent II': 700, 'Argent III': 800,
        'Or I': 900, 'Or II': 1000, 'Or III': 1100,
        'Platine I': 1200, 'Platine II': 1300, 'Platine III': 1400,
        'Diamant I': 1500, 'Diamant II': 1600, 'Diamant III': 1700,
        'Immortel': 1800, 'Radiant': 2000
    };
    
    const baseMMR = rankSystem[rank] || 0;
    const stats = playerData.stats || {};
    const gamesPlayed = stats.gamesPlayed || 1;
    const winRate = (stats.wins || 0) / gamesPlayed;
    const kdRatio = (stats.kills || 0) / Math.max(stats.deaths || 1, 1);
    
    const winRateBonus = (winRate - 0.5) * 100;
    const kdBonus = (kdRatio - 1) * 50;
    
    return Math.max(0, baseMMR + winRateBonus + kdBonus);
}

// Obtenir la valeur pour le classement selon le type
function getLeaderboardValue(stats, type) {
    switch (type) {
        case 'kills':
            return stats.kills || 0;
        case 'wins':
            return stats.wins || 0;
        case 'kd':
            const kills = stats.kills || 0;
            const deaths = stats.deaths || 0;
            return deaths > 0 ? kills / deaths : kills;
        case 'level':
            return calculateLevel(stats.experience || 0);
        default:
            return 0;
    }
}

// Formater la valeur pour l'affichage du classement
function formatLeaderboardValue(value, type) {
    switch (type) {
        case 'kd':
            return value.toFixed(2);
        case 'level':
            return `Niv. ${value}`;
        case 'competitive':
        case 'duel':
            return `${Math.round(value)} MMR`;
        default:
            return value.toString();
    }
}

// Gestion des paramètres améliorée
function setupSettingsListeners() {
    // Sliders de volume
    document.querySelectorAll('input[type="range"][data-setting]').forEach(slider => {
        slider.addEventListener('input', (e) => {
            const setting = e.target.getAttribute('data-setting');
            const value = e.target.value;
            
            // Mettre à jour l'affichage de la valeur
            updateSliderDisplay(e);
            
            // Appliquer les paramètres
            if (AppState && AppState.gameSettings) {
                if (setting === 'masterVolume' || setting === 'effectsVolume') {
                    AppState.gameSettings[setting] = value / 100;
                } else {
                    AppState.gameSettings[setting] = parseInt(value);
                }
                
                applySettings();
                saveUserSettings();
            }
        });
    });
    
    // Sélecteurs
    document.querySelectorAll('select[data-setting]').forEach(select => {
        select.addEventListener('change', (e) => {
            const setting = e.target.getAttribute('data-setting');
            const value = e.target.value;
            
            if (AppState && AppState.gameSettings) {
                AppState.gameSettings[setting] = value;
                applySettings();
                saveUserSettings();
            }
        });
    });
    
    // Checkboxes
    document.querySelectorAll('input[type="checkbox"][data-setting]').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            const setting = e.target.getAttribute('data-setting');
            const value = e.target.checked;
            
            if (AppState && AppState.gameSettings) {
                AppState.gameSettings[setting] = value;
                applySettings();
                saveUserSettings();
            }
        });
    });
}

// Mise à jour de l'affichage des sliders
function updateSliderDisplay(e) {
    const slider = e.target;
    const setting = slider.getAttribute('data-setting');
    const value = slider.value;
    
    // Trouver l'élément d'affichage correspondant
    let displayElement = null;
    if (setting === 'masterVolume' || setting === 'effectsVolume') {
        displayElement = slider.parentElement.querySelector('.volume-value');
        if (displayElement) {
            displayElement.textContent = `${value}%`;
        }
    } else if (setting === 'mouseSensitivity') {
        displayElement = slider.parentElement.querySelector('.sensitivity-value');
        if (displayElement) {
            displayElement.textContent = value;
        }
    }
}

// Charger les paramètres actuels
function loadCurrentSettings() {
    if (!AppState || !AppState.gameSettings) return;
    
    const settings = AppState.gameSettings;
    
    // Mettre à jour les sliders
    Object.keys(settings).forEach(setting => {
        const element = document.querySelector(`[data-setting="${setting}"]`);
        if (!element) return;
        
        if (element.type === 'range') {
            if (setting === 'masterVolume' || setting === 'effectsVolume') {
                element.value = settings[setting] * 100;
            } else {
                element.value = settings[setting];
            }
            // Déclencher l'événement pour mettre à jour l'affichage
            element.dispatchEvent(new Event('input'));
        } else if (element.type === 'checkbox') {
            element.checked = settings[setting];
        } else if (element.tagName === 'SELECT') {
            element.value = settings[setting];
        }
    });
}

// Application des paramètres
function applySettings() {
    if (!AppState || !AppState.gameSettings) return;
    
    const settings = AppState.gameSettings;
    
    // Appliquer le volume
    document.documentElement.style.setProperty('--master-volume', settings.masterVolume || 0.5);
    document.documentElement.style.setProperty('--effects-volume', settings.effectsVolume || 0.7);
    
    // Appliquer la qualité graphique
    document.documentElement.classList.remove('graphics-low', 'graphics-medium', 'graphics-high');
    document.documentElement.classList.add(`graphics-${settings.graphics || 'medium'}`);
    
    // Appliquer la sensibilité de la souris (pour le jeu)
    if (typeof player !== 'undefined') {
        player.mouseSensitivity = settings.mouseSensitivity || 5;
    }
}

// Sauvegarde des paramètres utilisateur
async function saveUserSettings() {
    if (!currentUser || !AppState || !AppState.gameSettings) return;
    
    try {
        const settingsRef = database.ref(`users/${currentUser.uid}/settings`);
        await settingsRef.set(AppState.gameSettings);
        console.log('Paramètres sauvegardés');
    } catch (error) {
        console.error('Erreur sauvegarde paramètres:', error);
    }
}

// Messages de notification
function showMessage(message, type = 'info', duration = 3000) {
    // Supprimer les anciens messages
    const existingMessage = document.querySelector('.menu-message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // Créer le nouveau message
    const messageDiv = document.createElement('div');
    messageDiv.className = `menu-message ${type}`;
    messageDiv.textContent = message;
    
    // Styles pour le message
    const colors = {
        success: '#4ade80',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#00d4ff'
    };
    
    messageDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 10px;
        color: white;
        font-weight: bold;
        z-index: 2000;
        animation: slideInRight 0.3s ease;
        background: rgba(0, 0, 0, 0.9);
        border: 2px solid ${colors[type] || colors.info};
        backdrop-filter: blur(10px);
        max-width: 300px;
    `;
    
    document.body.appendChild(messageDiv);
    
    // Supprimer le message après la durée spécifiée
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.style.animation = 'slideOutRight 0.3s ease forwards';
            setTimeout(() => messageDiv.remove(), 300);
        }
    }, duration);
}

// Mise à jour du statut en ligne
function updateOnlineStatus() {
    if (!currentUser) return;
    
    const statusRef = database.ref(`users/${currentUser.uid}/status`);
    
    // Marquer comme en ligne
    statusRef.set('online');
    
    // Marquer comme hors ligne lors de la déconnexion
    statusRef.onDisconnect().set('offline');
    
    // Gérer les changements de visibilité de la page
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            statusRef.set('away');
        } else {
            statusRef.set('online');
        }
    });
}

// Intégration avec le système de profils
auth.onAuthStateChanged((user) => {
    if (user) {
        updateOnlineStatus();
        
        // Charger les paramètres utilisateur
        setTimeout(() => {
            loadUserSettings();
        }, 1000);
    }
});

// Charger les paramètres utilisateur depuis Firebase
async function loadUserSettings() {
    if (!currentUser) return;
    
    try {
        const settingsRef = database.ref(`users/${currentUser.uid}/settings`);
        const snapshot = await settingsRef.once('value');
        
        if (snapshot.exists()) {
            const userSettings = snapshot.val();
            
            // Fusionner avec les paramètres par défaut
            if (AppState && AppState.gameSettings) {
                AppState.gameSettings = { ...AppState.gameSettings, ...userSettings };
                applySettings();
                loadCurrentSettings(); // Mettre à jour l'interface
            }
        }
    } catch (error) {
        console.error('Erreur chargement paramètres utilisateur:', error);
    }
}

// CSS supplémentaire pour les nouvelles fonctionnalités
const additionalMenuStyles = document.createElement('style');
additionalMenuStyles.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .weapon-details {
        margin-top: 10px;
        padding-top: 10px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .weapon-detail {
        font-size: 12px;
        color: rgba(255, 255, 255, 0.7);
        margin-bottom: 5px;
    }
    
    .menu-message {
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
    }
    
    .game-mode.selected {
        background: rgba(0, 212, 255, 0.2);
        border-color: #00d4ff;
        box-shadow: 0 0 20px rgba(0, 212, 255, 0.3);
        transform: translateY(-2px);
    }
    
    .weapon-card.selected {
        background: rgba(0, 212, 255, 0.2);
        border-color: #00d4ff;
        box-shadow: 0 0 20px rgba(0, 212, 255, 0.3);
        transform: translateY(-2px);
    }
    
    .launch-game-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none !important;
        animation: none !important;
    }
    
    .friends-search {
        position: relative;
    }
    
    .friends-search input:focus {
        border-color: #00d4ff;
        box-shadow: 0 0 15px rgba(0, 212, 255, 0.3);
    }
    
    .setting-item {
        align-items: center;
        gap: 15px;
    }
    
    .volume-value,
    .sensitivity-value {
        min-width: 50px;
        text-align: center;
        font-weight: bold;
        color: #00d4ff;
    }
`;
document.head.appendChild(additionalMenuStyles);

console.log('Menu amélioré initialisé avec support des nouveaux modes');