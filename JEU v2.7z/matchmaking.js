// Système de matchmaking avancé avec modes de jeu

// Configuration des modes de jeu
const gameModes = {
    duel: {
        name: 'Duel',
        description: '1v1 - Premier à 5 rounds',
        maxPlayers: 2,
        maxRounds: 9,
        winCondition: 5,
        economy: true,
        ranked: true
    },
    competitive: {
        name: 'Compétitif',
        description: '5v5 - Premier à 13 rounds',
        maxPlayers: 10,
        maxRounds: 25,
        winCondition: 13,
        economy: true,
        ranked: true
    },
    deathmatch: {
        name: 'Deathmatch',
        description: 'Combat libre - 10 minutes',
        maxPlayers: 14,
        maxRounds: 1,
        winCondition: 50, // Premier à 50 kills
        economy: false,
        ranked: false
    },
    unrated: {
        name: 'Non classé',
        description: '5v5 - Mode casual',
        maxPlayers: 10,
        maxRounds: 25,
        winCondition: 13,
        economy: true,
        ranked: false
    }
};

// Système de rangs pour le matchmaking
const rankSystem = {
    'Fer I': { mmr: 0, variance: 50 },
    'Fer II': { mmr: 100, variance: 50 },
    'Fer III': { mmr: 200, variance: 50 },
    'Bronze I': { mmr: 300, variance: 45 },
    'Bronze II': { mmr: 400, variance: 45 },
    'Bronze III': { mmr: 500, variance: 45 },
    'Argent I': { mmr: 600, variance: 40 },
    'Argent II': { mmr: 700, variance: 40 },
    'Argent III': { mmr: 800, variance: 40 },
    'Or I': { mmr: 900, variance: 35 },
    'Or II': { mmr: 1000, variance: 35 },
    'Or III': { mmr: 1100, variance: 35 },
    'Platine I': { mmr: 1200, variance: 30 },
    'Platine II': { mmr: 1300, variance: 30 },
    'Platine III': { mmr: 1400, variance: 30 },
    'Diamant I': { mmr: 1500, variance: 25 },
    'Diamant II': { mmr: 1600, variance: 25 },
    'Diamant III': { mmr: 1700, variance: 25 },
    'Immortel': { mmr: 1800, variance: 20 },
    'Radiant': { mmr: 2000, variance: 15 }
};

// État du matchmaking
let matchmakingState = {
    inQueue: false,
    queueStartTime: null,
    selectedMode: null,
    selectedMap: null,
    preferences: {
        region: 'EU',
        maxPing: 100,
        allowHigherRanks: true,
        preferredLanguage: 'fr'
    }
};

// File d'attente et recherche de parties
class MatchmakingSystem {
    constructor() {
        this.queue = new Map();
        this.activeMatches = new Map();
        this.playerData = new Map();
        this.listeners = new Map();
    }

    // Rejoindre la file d'attente
    async joinQueue(mode, map = null, options = {}) {
        if (matchmakingState.inQueue) {
            throw new Error('Déjà en file d\'attente');
        }

        if (!currentUser) {
            throw new Error('Utilisateur non connecté');
        }

        try {
            // Récupérer les données du joueur
            const playerData = await this.getPlayerData(currentUser.uid);
            
            // Valider le mode de jeu
            if (!gameModes[mode]) {
                throw new Error('Mode de jeu invalide');
            }

            // Créer l'entrée de file d'attente
            const queueEntry = {
                playerId: currentUser.uid,
                playerName: playerData.displayName || 'Joueur',
                playerRank: playerData.rank || 'Fer I',
                playerLevel: playerData.level || 1,
                playerMMR: this.calculateMMR(playerData),
                mode: mode,
                map: map,
                region: options.region || 'EU',
                maxPing: options.maxPing || 100,
                queueTime: firebase.database.ServerValue.TIMESTAMP,
                preferences: {
                    ...matchmakingState.preferences,
                    ...options
                }
            };

            // Ajouter à la file Firebase
            const queueRef = database.ref('matchmaking/queue').push();
            await queueRef.set(queueEntry);

            // Mettre à jour l'état local
            matchmakingState = {
                inQueue: true,
                queueStartTime: Date.now(),
                selectedMode: mode,
                selectedMap: map,
                queueId: queueRef.key
            };

            // Démarrer la recherche de partie
            this.startMatchmaking(queueRef.key, queueEntry);

            console.log(`Rejoint la file d'attente: ${mode} ${map || 'auto'}`);
            return queueRef.key;

        } catch (error) {
            console.error('Erreur rejoindre file:', error);
            throw error;
        }
    }

    // Quitter la file d'attente
    async leaveQueue() {
        if (!matchmakingState.inQueue) return;

        try {
            // Supprimer de Firebase
            if (matchmakingState.queueId) {
                await database.ref(`matchmaking/queue/${matchmakingState.queueId}`).remove();
            }

            // Arrêter les listeners
            this.stopMatchmakingListeners();

            // Reset l'état
            matchmakingState = {
                inQueue: false,
                queueStartTime: null,
                selectedMode: null,
                selectedMap: null,
                queueId: null
            };

            console.log('File d\'attente quittée');

        } catch (error) {
            console.error('Erreur quitter file:', error);
        }
    }

    // Démarrer la recherche de partie
    startMatchmaking(queueId, playerEntry) {
        // Écouter les mises à jour de la file
        const queueRef = database.ref(`matchmaking/queue/${queueId}`);
        
        const queueListener = queueRef.on('value', async (snapshot) => {
            const data = snapshot.val();
            
            if (!data) {
                // Entrée supprimée = match trouvé ou timeout
                this.stopMatchmakingListeners();
                return;
            }

            // Vérifier si un match a été assigné
            if (data.matchId) {
                console.log('Match trouvé:', data.matchId);
                await this.joinMatch(data.matchId);
                return;
            }

            // Mettre à jour le temps d'attente
            this.updateQueueTime(data.queueTime);
        });

        this.listeners.set('queue', queueListener);

        // Démarrer la logique de matching côté client
        this.attemptMatching(playerEntry);
    }

    // Tentative de création de match
    async attemptMatching(playerEntry) {
        const matchingInterval = setInterval(async () => {
            if (!matchmakingState.inQueue) {
                clearInterval(matchingInterval);
                return;
            }

            try {
                await this.findCompatiblePlayers(playerEntry);
            } catch (error) {
                console.error('Erreur recherche joueurs:', error);
            }

        }, 5000); // Vérifier toutes les 5 secondes

        // Timeout après 5 minutes
        setTimeout(() => {
            if (matchmakingState.inQueue) {
                clearInterval(matchingInterval);
                this.handleQueueTimeout();
            }
        }, 300000);
    }

    // Rechercher des joueurs compatibles
    async findCompatiblePlayers(playerEntry) {
        const queueRef = database.ref('matchmaking/queue');
        const snapshot = await queueRef.once('value');
        const allPlayers = snapshot.val() || {};

        // Filtrer les joueurs compatibles
        const compatiblePlayers = Object.entries(allPlayers)
            .map(([id, data]) => ({ id, ...data }))
            .filter(player => this.isCompatible(playerEntry, player))
            .sort((a, b) => this.calculateCompatibilityScore(playerEntry, b) - 
                           this.calculateCompatibilityScore(playerEntry, a));

        const mode = gameModes[playerEntry.mode];
        
        // Vérifier si on a assez de joueurs
        if (compatiblePlayers.length >= mode.maxPlayers) {
            const selectedPlayers = compatiblePlayers.slice(0, mode.maxPlayers);
            await this.createMatch(selectedPlayers, playerEntry.mode, playerEntry.map);
        }
    }

    // Vérifier la compatibilité entre joueurs
    isCompatible(player1, player2) {
        // Même mode de jeu
        if (player1.mode !== player2.mode) return false;

        // Même région (ou proche)
        if (player1.region !== player2.region) return false;

        // Différence de MMR acceptable
        const mmrDiff = Math.abs(player1.playerMMR - player2.playerMMR);
        const maxDiff = this.getMaxMMRDifference(player1, player2);
        
        if (mmrDiff > maxDiff) return false;

        // Ping acceptable
        if (player1.maxPing < 50 && player2.maxPing < 50) return true;

        return true;
    }

    // Calculer la différence MMR maximale acceptable
    getMaxMMRDifference(player1, player2) {
        const queueTime1 = Date.now() - (player1.queueTime || Date.now());
        const queueTime2 = Date.now() - (player2.queueTime || Date.now());
        const avgQueueTime = (queueTime1 + queueTime2) / 2;

        // Élargir les critères avec le temps d'attente
        const baseVariance = 100;
        const timeMultiplier = Math.min(avgQueueTime / 120000, 3); // Max 3x après 2 minutes
        
        return baseVariance * (1 + timeMultiplier);
    }

    // Calculer le score de compatibilité
    calculateCompatibilityScore(player1, player2) {
        let score = 100;

        // MMR similaire = meilleur score
        const mmrDiff = Math.abs(player1.playerMMR - player2.playerMMR);
        score -= mmrDiff * 0.1;

        // Ping similaire
        const pingDiff = Math.abs(player1.maxPing - player2.maxPing);
        score -= pingDiff * 0.05;

        // Temps d'attente (prioriser ceux qui attendent le plus)
        const queueTime = Date.now() - (player2.queueTime || Date.now());
        score += queueTime * 0.0001;

        return Math.max(0, score);
    }

    // Créer une nouvelle partie
    async createMatch(players, mode, map) {
        try {
            const matchId = database.ref('matches').push().key;
            const selectedMap = map || this.selectRandomMap(mode);
            
            // Équilibrer les équipes pour les modes 5v5
            const teams = this.balanceTeams(players, mode);

            const matchData = {
                id: matchId,
                mode: mode,
                map: selectedMap,
                status: 'forming',
                players: teams.all.reduce((acc, player) => {
                    acc[player.playerId] = {
                        name: player.playerName,
                        rank: player.playerRank,
                        level: player.playerLevel,
                        mmr: player.playerMMR,
                        team: teams.teamA.includes(player) ? 'attackers' : 'defenders',
                        ready: false,
                        connected: false
                    };
                    return acc;
                }, {}),
                settings: {
                    maxPlayers: gameModes[mode].maxPlayers,
                    maxRounds: gameModes[mode].maxRounds,
                    winCondition: gameModes[mode].winCondition,
                    economy: gameModes[mode].economy,
                    ranked: gameModes[mode].ranked
                },
                createdAt: firebase.database.ServerValue.TIMESTAMP,
                region: players[0].region
            };

            // Créer le match dans Firebase
            await database.ref(`matches/${matchId}`).set(matchData);

            // Notifier tous les joueurs
            const notifications = players.map(player => 
                this.notifyPlayerMatchFound(player.playerId, matchId, player.id)
            );

            await Promise.all(notifications);

            console.log(`Match créé: ${matchId} (${mode} sur ${selectedMap})`);
            return matchId;

        } catch (error) {
            console.error('Erreur création match:', error);
            throw error;
        }
    }

    // Équilibrer les équipes
    balanceTeams(players, mode) {
        if (mode === 'duel' || mode === 'deathmatch') {
            return { all: players, teamA: [players[0]], teamB: [players[1]] };
        }

        // Trier par MMR
        const sortedPlayers = [...players].sort((a, b) => b.playerMMR - a.playerMMR);
        
        const teamA = [];
        const teamB = [];
        let teamAMMR = 0;
        let teamBMMR = 0;

        // Distribution en zigzag pour équilibrer
        sortedPlayers.forEach((player, index) => {
            if (teamA.length === 5) {
                teamB.push(player);
                teamBMMR += player.playerMMR;
            } else if (teamB.length === 5) {
                teamA.push(player);
                teamAMMR += player.playerMMR;
            } else {
                // Ajouter au team avec le MMR le plus faible
                if (teamAMMR <= teamBMMR) {
                    teamA.push(player);
                    teamAMMR += player.playerMMR;
                } else {
                    teamB.push(player);
                    teamBMMR += player.playerMMR;
                }
            }
        });

        return { all: players, teamA, teamB };
    }

    // Notifier un joueur qu'un match a été trouvé
    async notifyPlayerMatchFound(playerId, matchId, queueId) {
        try {
            // Mettre à jour l'entrée de file avec le match ID
            await database.ref(`matchmaking/queue/${queueId}`).update({
                matchId: matchId,
                status: 'match_found'
            });

            // Envoyer une notification
            await database.ref(`users/${playerId}/notifications`).push({
                type: 'match_found',
                matchId: matchId,
                timestamp: firebase.database.ServerValue.TIMESTAMP
            });

        } catch (error) {
            console.error('Erreur notification match:', error);
        }
    }

    // Rejoindre un match trouvé
    async joinMatch(matchId) {
        try {
            // Quitter la file d'attente
            await this.leaveQueue();

            // Rejoindre le match
            const matchRef = database.ref(`matches/${matchId}`);
            const snapshot = await matchRef.once('value');
            const matchData = snapshot.val();

            if (!matchData) {
                throw new Error('Match introuvable');
            }

            // Marquer comme connecté
            await matchRef.child(`players/${currentUser.uid}`).update({
                connected: true,
                joinedAt: firebase.database.ServerValue.TIMESTAMP
            });

            // Attendre que tous les joueurs se connectent
            this.waitForAllPlayers(matchId, matchData);

        } catch (error) {
            console.error('Erreur rejoindre match:', error);
            throw error;
        }
    }

    // Attendre que tous les joueurs rejoignent
    waitForAllPlayers(matchId, matchData) {
        const matchRef = database.ref(`matches/${matchId}`);
        
        const playerListener = matchRef.child('players').on('value', (snapshot) => {
            const players = snapshot.val() || {};
            const connectedPlayers = Object.values(players).filter(p => p.connected).length;
            const totalPlayers = Object.keys(players).length;

            console.log(`Joueurs connectés: ${connectedPlayers}/${totalPlayers}`);

            if (connectedPlayers === totalPlayers) {
                // Tous les joueurs sont connectés
                matchRef.off('value', playerListener);
                this.startMatchCountdown(matchId, matchData);
            }
        });

        // Timeout si tous les joueurs ne rejoignent pas
        setTimeout(() => {
            matchRef.off('value', playerListener);
            this.handleMatchTimeout(matchId);
        }, 60000); // 60 secondes
    }

    // Démarrer le compte à rebours du match
    async startMatchCountdown(matchId, matchData) {
        try {
            // Mettre à jour le statut du match
            await database.ref(`matches/${matchId}`).update({
                status: 'starting',
                startCountdown: 10
            });

            // Afficher l'interface de préparation
            this.showMatchPreparation(matchData);

            // Compte à rebours
            let countdown = 10;
            const countdownInterval = setInterval(async () => {
                countdown--;
                
                if (countdown > 0) {
                    await database.ref(`matches/${matchId}/startCountdown`).set(countdown);
                    this.updateCountdownDisplay(countdown);
                } else {
                    clearInterval(countdownInterval);
                    await this.startMatch(matchId, matchData);
                }
            }, 1000);

        } catch (error) {
            console.error('Erreur compte à rebours:', error);
        }
    }

    // Démarrer le match
    async startMatch(matchId, matchData) {
        try {
            // Mettre à jour le statut
            await database.ref(`matches/${matchId}`).update({
                status: 'active',
                startedAt: firebase.database.ServerValue.TIMESTAMP
            });

            // Assigner l'équipe du joueur
            const playerData = matchData.players[currentUser.uid];
            if (playerData) {
                player.team = playerData.team;
                game.mode = matchData.mode;
                game.currentMap = matchData.map;
                game.matchId = matchId;
            }

            // Démarrer le jeu
            console.log('Match démarré!');
            initializeGame();
            showGameScreen();

        } catch (error) {
            console.error('Erreur démarrage match:', error);
        }
    }

    // Afficher l'interface de préparation
    showMatchPreparation(matchData) {
        const preparationScreen = document.createElement('div');
        preparationScreen.id = 'match-preparation';
        preparationScreen.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            color: white;
        `;

        preparationScreen.innerHTML = `
            <div style="text-align: center; max-width: 800px;">
                <h1 style="font-size: 48px; margin-bottom: 20px; color: #00d4ff;">MATCH TROUVÉ</h1>
                
                <div style="display: flex; justify-content: space-between; margin: 40px 0; padding: 20px; background: rgba(255,255,255,0.1); border-radius: 15px;">
                    <div style="text-align: center;">
                        <h3 style="color: #ff4655; margin-bottom: 10px;">MODE</h3>
                        <p style="font-size: 18px;">${gameModes[matchData.mode].name}</p>
                    </div>
                    <div style="text-align: center;">
                        <h3 style="color: #ffd700; margin-bottom: 10px;">CARTE</h3>
                        <p style="font-size: 18px;">${matchData.map}</p>
                    </div>
                    <div style="text-align: center;">
                        <h3 style="color: #4ade80; margin-bottom: 10px;">JOUEURS</h3>
                        <p style="font-size: 18px;">${Object.keys(matchData.players).length}/${gameModes[matchData.mode].maxPlayers}</p>
                    </div>
                </div>

                <div id="countdown-display" style="font-size: 72px; font-weight: bold; color: #ff4655; margin: 40px 0;">
                    10
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 40px;">
                    <div>
                        <h3 style="color: #ff4655; margin-bottom: 15px;">ATTAQUANTS</h3>
                        <div id="team-attackers">
                            ${this.renderTeamPlayers(matchData.players, 'attackers')}
                        </div>
                    </div>
                    <div>
                        <h3 style="color: #00d4ff; margin-bottom: 15px;">DÉFENSEURS</h3>
                        <div id="team-defenders">
                            ${this.renderTeamPlayers(matchData.players, 'defenders')}
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(preparationScreen);
    }

    // Afficher les joueurs d'une équipe
    renderTeamPlayers(players, team) {
        return Object.entries(players)
            .filter(([id, data]) => data.team === team)
            .map(([id, data]) => `
                <div style="display: flex; align-items: center; justify-content: space-between; padding: 10px; background: rgba(255,255,255,0.05); border-radius: 8px; margin-bottom: 8px;">
                    <div>
                        <span style="font-weight: bold;">${data.name}</span>
                        <span style="color: rgba(255,255,255,0.7); margin-left: 10px;">${data.rank}</span>
                    </div>
                    <div style="color: ${data.connected ? '#4ade80' : '#ef4444'};">
                        <i class="fas fa-${data.connected ? 'check' : 'clock'}"></i>
                    </div>
                </div>
            `).join('');
    }

    // Mettre à jour l'affichage du compte à rebours
    updateCountdownDisplay(countdown) {
        const display = document.getElementById('countdown-display');
        if (display) {
            display.textContent = countdown;
            display.style.color = countdown <= 3 ? '#ff0000' : '#ff4655';
        }
    }

    // Gérer le timeout de la file d'attente
    handleQueueTimeout() {
        console.log('Timeout de la file d\'attente');
        this.leaveQueue();
        
        // Afficher un message à l'utilisateur
        const message = document.createElement('div');
        message.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(239, 68, 68, 0.9);
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            font-size: 18px;
            z-index: 1000;
        `;
        message.textContent = 'Aucun match trouvé. Réessayez plus tard.';
        
        document.body.appendChild(message);
        setTimeout(() => message.remove(), 5000);
    }

    // Gérer le timeout du match
    async handleMatchTimeout(matchId) {
        console.log('Timeout du match');
        
        try {
            await database.ref(`matches/${matchId}`).update({
                status: 'cancelled',
                reason: 'timeout'
            });
        } catch (error) {
            console.error('Erreur timeout match:', error);
        }
    }

    // Arrêter les listeners de matchmaking
    stopMatchmakingListeners() {
        this.listeners.forEach((listener, key) => {
            if (key === 'queue') {
                database.ref(`matchmaking/queue/${matchmakingState.queueId}`).off('value', listener);
            }
        });
        this.listeners.clear();
    }

    // Sélectionner une carte aléatoire
    selectRandomMap(mode) {
        const availableMaps = Object.keys(maps);
        return availableMaps[Math.floor(Math.random() * availableMaps.length)];
    }

    // Calculer le MMR d'un joueur
    calculateMMR(playerData) {
        const rank = playerData.rank || 'Fer I';
        const baseMMR = rankSystem[rank]?.mmr || 0;
        
        // Ajustements basés sur les performances
        const stats = playerData.stats || {};
        const gamesPlayed = stats.gamesPlayed || 1;
        const winRate = (stats.wins || 0) / gamesPlayed;
        const kdRatio = (stats.kills || 0) / Math.max(stats.deaths || 1, 1);
        
        // Bonus/malus de performance
        const winRateBonus = (winRate - 0.5) * 100;
        const kdBonus = (kdRatio - 1) * 50;
        
        return Math.max(0, baseMMR + winRateBonus + kdBonus);
    }

    // Récupérer les données d'un joueur
    async getPlayerData(playerId) {
        try {
            const userRef = database.ref(`users/${playerId}`);
            const snapshot = await userRef.once('value');
            return snapshot.val() || {};
        } catch (error) {
            console.error('Erreur récupération données joueur:', error);
            return {};
        }
    }

    // Mettre à jour le temps d'attente affiché
    updateQueueTime(queueStartTime) {
        const queueTimeDisplay = document.getElementById('queue-time');
        if (queueTimeDisplay && queueStartTime) {
            const elapsed = Math.floor((Date.now() - queueStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            queueTimeDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
    }
}

// Instance globale du système de matchmaking
const matchmaking = new MatchmakingSystem();

// Fonctions publiques pour l'interface
async function findMatch(mode, map = null, options = {}) {
    try {
        showMatchmakingUI(mode, map);
        const queueId = await matchmaking.joinQueue(mode, map, options);
        return queueId;
    } catch (error) {
        console.error('Erreur recherche de partie:', error);
        hideMatchmakingUI();
        throw error;
    }
}

async function cancelMatchmaking() {
    try {
        await matchmaking.leaveQueue();
        hideMatchmakingUI();
    } catch (error) {
        console.error('Erreur annulation matchmaking:', error);
    }
}

// Interface de matchmaking
function showMatchmakingUI(mode, map) {
    const matchmakingUI = document.createElement('div');
    matchmakingUI.id = 'matchmaking-ui';
    matchmakingUI.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(15, 20, 25, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 20px;
        padding: 40px;
        z-index: 1500;
        text-align: center;
        backdrop-filter: blur(10px);
        min-width: 400px;
    `;

    matchmakingUI.innerHTML = `
        <div style="margin-bottom: 20px;">
            <div style="width: 60px; height: 60px; border: 4px solid rgba(0, 212, 255, 0.3); 
                        border-top: 4px solid #00d4ff; border-radius: 50%; 
                        animation: spin 1s linear infinite; margin: 0 auto 20px;">
            </div>
            <h2 style="color: #00d4ff; margin-bottom: 10px;">Recherche de partie</h2>
            <p style="color: rgba(255, 255, 255, 0.7); margin-bottom: 20px;">
                ${gameModes[mode].name} ${map ? `sur ${map}` : ''}
            </p>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; 
                    padding: 20px; background: rgba(255, 255, 255, 0.05); border-radius: 10px;">
            <div>
                <div style="color: rgba(255, 255, 255, 0.7); font-size: 12px; margin-bottom: 5px;">TEMPS D'ATTENTE</div>
                <div id="queue-time" style="font-size: 24px; font-weight: bold; color: #ffd700;">0:00</div>
            </div>
            <div>
                <div style="color: rgba(255, 255, 255, 0.7); font-size: 12px; margin-bottom: 5px;">JOUEURS EN FILE</div>
                <div id="queue-count" style="font-size: 24px; font-weight: bold; color: #4ade80;">~</div>
            </div>
        </div>

        <div style="margin-bottom: 20px;">
            <div style="color: rgba(255, 255, 255, 0.7); font-size: 14px; margin-bottom: 10px;">
                Temps d'attente estimé: <span style="color: #00d4ff;">2-3 minutes</span>
            </div>
            <div style="color: rgba(255, 255, 255, 0.5); font-size: 12px;">
                Vous pouvez quitter à tout moment sans pénalité
            </div>
        </div>

        <button onclick="cancelMatchmaking()" style="
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid #ef4444;
            border-radius: 10px;
            color: #ef4444;
            padding: 12px 24px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
        ">
            <i class="fas fa-times"></i> Annuler
        </button>
    `;

    // Ajouter l'animation de rotation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);

    document.body.appendChild(matchmakingUI);
    
    // Démarrer la mise à jour du temps
    updateQueueTimeDisplay();
}

function hideMatchmakingUI() {
    const ui = document.getElementById('matchmaking-ui');
    if (ui) {
        ui.remove();
    }
    
    const preparation = document.getElementById('match-preparation');
    if (preparation) {
        preparation.remove();
    }
}

function updateQueueTimeDisplay() {
    if (!matchmakingState.inQueue) return;
    
    const interval = setInterval(() => {
        if (!matchmakingState.inQueue) {
            clearInterval(interval);
            return;
        }
        
        const elapsed = Math.floor((Date.now() - matchmakingState.queueStartTime) / 1000);
        const minutes = Math.floor(elapsed / 60);
        const seconds = elapsed % 60;
        
        const display = document.getElementById('queue-time');
        if (display) {
            display.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
    }, 1000);
}

// Système de reconnexion
async function checkForActiveMatch() {
    if (!currentUser) return null;
    
    try {
        // Vérifier s'il y a un match actif pour ce joueur
        const matchesRef = database.ref('matches');
        const snapshot = await matchesRef.orderByChild('status').equalTo('active').once('value');
        const matches = snapshot.val() || {};
        
        for (const [matchId, matchData] of Object.entries(matches)) {
            if (matchData.players && matchData.players[currentUser.uid]) {
                console.log('Match actif trouvé:', matchId);
                return { matchId, matchData };
            }
        }
        
        return null;
    } catch (error) {
        console.error('Erreur vérification match actif:', error);
        return null;
    }
}

// Proposer la reconnexion
async function handleReconnection() {
    const activeMatch = await checkForActiveMatch();
    
    if (activeMatch) {
        const reconnectModal = document.createElement('div');
        reconnectModal.style.cssText = `
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0, 0, 0, 0.9);
            display: flex; justify-content: center; align-items: center;
            z-index: 2000;
        `;
        
        reconnectModal.innerHTML = `
            <div style="background: rgba(15, 20, 25, 0.95); padding: 40px; border-radius: 20px; text-align: center; max-width: 500px;">
                <h2 style="color: #00d4ff; margin-bottom: 20px;">Partie en cours détectée</h2>
                <p style="color: rgba(255, 255, 255, 0.8); margin-bottom: 30px; line-height: 1.5;">
                    Vous avez une partie ${gameModes[activeMatch.matchData.mode].name} en cours sur ${activeMatch.matchData.map}.
                    Voulez-vous la rejoindre ?
                </p>
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button onclick="reconnectToMatch('${activeMatch.matchId}')" style="
                        background: linear-gradient(45deg, #00d4ff, #0099cc);
                        border: none; border-radius: 10px; color: white; padding: 15px 25px;
                        font-size: 16px; font-weight: bold; cursor: pointer;
                    ">
                        Rejoindre
                    </button>
                    <button onclick="this.parentElement.parentElement.parentElement.remove()" style="
                        background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.3);
                        border-radius: 10px; color: white; padding: 15px 25px;
                        font-size: 16px; cursor: pointer;
                    ">
                        Ignorer
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(reconnectModal);
    }
}

async function reconnectToMatch(matchId) {
    try {
        // Rejoindre le match
        await matchmaking.joinMatch(matchId);
        
        // Fermer le modal
        const modal = document.querySelector('.reconnect-modal');
        if (modal) modal.remove();
        
    } catch (error) {
        console.error('Erreur reconnexion:', error);
    }
}

// Initialisation
document.addEventListener('DOMContentLoaded', () => {
    // Vérifier s'il y a un match actif au chargement
    auth.onAuthStateChanged((user) => {
        if (user) {
            setTimeout(handleReconnection, 2000); // Attendre 2 secondes après connexion
        }
    });
});

// Export pour utilisation dans d'autres modules
window.MatchmakingSystem = matchmaking;
window.MatchmakingSystem.gameModes = gameModes;
window.MatchmakingSystem.findMatch = findMatch;
window.MatchmakingSystem.cancelMatchmaking = cancelMatchmaking;
window.MatchmakingSystem.checkForActiveMatch = checkForActiveMatch;
window.MatchmakingSystem.handleReconnection = handleReconnection;
window.MatchmakingSystem.reconnectToMatch = reconnectToMatch;
window.MatchmakingSystem.matchmakingState = matchmakingState;