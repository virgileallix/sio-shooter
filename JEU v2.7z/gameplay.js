// Système de gameplay principal avec logique Valorant

// Variables de jeu
let gameCanvas;
let gameContext;
let minimapCanvas;
let minimapContext;
let gameLoop;
let keys = {};
let mouse = { x: 0, y: 0, pressed: false };

// État du joueur
let player = {
    x: 400,
    y: 300,
    angle: 0,
    speed: 3,
    health: 100,
    armor: 0,
    money: 800,
    weapon: {
        name: 'Classic',
        ammo: 12,
        totalAmmo: 36,
        damage: 26,
        fireRate: 6.75,
        lastShot: 0,
        penetration: 1,
        price: 0
    },
    team: 'attackers',
    alive: true,
    kills: 0,
    deaths: 0,
    roundKills: 0,
    equipped: ['Classic']
};

// État du jeu avec logique Valorant
let game = {
    mode: 'competitive', // competitive, duel, deathmatch
    round: 1,
    roundTime: 100, // 100 secondes par round
    buyTime: 30, // 30 secondes de buy time
    attackersScore: 0,
    defendersScore: 0,
    gameStarted: false,
    gamePaused: false,
    currentMap: 'dust2',
    matchId: null,
    matchStartTime: null,
    roundStartTime: null,
    phase: 'buy', // buy, active, ended
    bomb: {
        planted: false,
        defused: false,
        site: null,
        timer: 45, // 45 secondes pour exploser
        defuseTime: 7, // 7 secondes pour désamorcer
        plantTime: 4, // 4 secondes pour planter
        defusing: false,
        planting: false,
        carrier: null
    },
    economy: {
        killReward: 200,
        winReward: 3000,
        lossReward: [1900, 2400, 2900], // Bonus consécutif
        lossStreak: { attackers: 0, defenders: 0 }
    }
};

// Armes disponibles avec stats Valorant
const weapons = {
    pistols: {
        'Classic': { damage: 26, fireRate: 6.75, accuracy: 55, price: 0, ammo: 12, totalAmmo: 36, penetration: 1 },
        'Shorty': { damage: 12, fireRate: 3.3, accuracy: 35, price: 200, ammo: 2, totalAmmo: 10, penetration: 1 },
        'Frenzy': { damage: 22, fireRate: 10, accuracy: 45, price: 400, ammo: 13, totalAmmo: 39, penetration: 1 },
        'Ghost': { damage: 30, fireRate: 6.75, accuracy: 65, price: 500, ammo: 15, totalAmmo: 45, penetration: 2 },
        'Sheriff': { damage: 55, fireRate: 4, accuracy: 75, price: 800, ammo: 6, totalAmmo: 24, penetration: 3 }
    },
    smgs: {
        'Stinger': { damage: 27, fireRate: 16, accuracy: 60, price: 1100, ammo: 20, totalAmmo: 60, penetration: 1 },
        'Spectre': { damage: 26, fireRate: 13.33, accuracy: 65, price: 1600, ammo: 30, totalAmmo: 90, penetration: 2 }
    },
    rifles: {
        'Bulldog': { damage: 35, fireRate: 9.15, accuracy: 70, price: 2050, ammo: 24, totalAmmo: 72, penetration: 2 },
        'Guardian': { damage: 65, fireRate: 6.5, accuracy: 80, price: 2250, ammo: 12, totalAmmo: 36, penetration: 3 },
        'Phantom': { damage: 39, fireRate: 11, accuracy: 75, price: 2900, ammo: 30, totalAmmo: 90, penetration: 3 },
        'Vandal': { damage: 40, fireRate: 9.75, accuracy: 73, price: 2900, ammo: 25, totalAmmo: 75, penetration: 3 }
    },
    snipers: {
        'Marshal': { damage: 101, fireRate: 1.5, accuracy: 85, price: 950, ammo: 5, totalAmmo: 15, penetration: 2 },
        'Operator': { damage: 150, fireRate: 0.6, accuracy: 95, price: 4700, ammo: 5, totalAmmo: 15, penetration: 4 }
    },
    shotguns: {
        'Bucky': { damage: 34, fireRate: 1.1, accuracy: 40, price: 850, ammo: 5, totalAmmo: 15, penetration: 1 },
        'Judge': { damage: 17, fireRate: 3.5, accuracy: 35, price: 1850, ammo: 7, totalAmmo: 21, penetration: 1 }
    },
    utility: {
        'Light Armor': { price: 400, type: 'armor', value: 25 },
        'Heavy Armor': { price: 1000, type: 'armor', value: 50 },
        'Spike': { price: 0, type: 'spike' }
    }
};

// Cartes avec sites de bombe
const maps = {
    dust2: {
        name: 'Dust2',
        spawnPoints: {
            attackers: [
                { x: 100, y: 700 }, { x: 150, y: 700 }, { x: 200, y: 700 },
                { x: 100, y: 650 }, { x: 150, y: 650 }
            ],
            defenders: [
                { x: 1000, y: 100 }, { x: 1050, y: 100 }, { x: 1100, y: 100 },
                { x: 1000, y: 150 }, { x: 1050, y: 150 }
            ]
        },
        walls: [
            // Murs extérieurs
            { x: 0, y: 0, width: 1200, height: 20 },
            { x: 0, y: 780, width: 1200, height: 20 },
            { x: 0, y: 0, width: 20, height: 800 },
            { x: 1180, y: 0, width: 20, height: 800 },
            
            // Structures internes
            { x: 200, y: 200, width: 300, height: 20 },
            { x: 700, y: 200, width: 300, height: 20 },
            { x: 400, y: 300, width: 20, height: 200 },
            { x: 600, y: 300, width: 20, height: 200 },
            { x: 300, y: 550, width: 200, height: 20 },
            { x: 700, y: 550, width: 200, height: 20 }
        ],
        bombSites: [
            { name: 'A', x: 900, y: 150, width: 200, height: 150, planted: false },
            { name: 'B', x: 150, y: 550, width: 200, height: 150, planted: false }
        ]
    },
    haven: {
        name: 'Haven',
        spawnPoints: {
            attackers: [
                { x: 600, y: 50 }, { x: 650, y: 50 }, { x: 700, y: 50 },
                { x: 600, y: 100 }, { x: 650, y: 100 }
            ],
            defenders: [
                { x: 200, y: 700 }, { x: 250, y: 700 }, { x: 300, y: 700 },
                { x: 900, y: 700 }, { x: 950, y: 700 }
            ]
        },
        walls: [
            { x: 0, y: 0, width: 1200, height: 20 },
            { x: 0, y: 780, width: 1200, height: 20 },
            { x: 0, y: 0, width: 20, height: 800 },
            { x: 1180, y: 0, width: 20, height: 800 },
            
            { x: 300, y: 200, width: 20, height: 200 },
            { x: 880, y: 200, width: 20, height: 200 },
            { x: 500, y: 350, width: 200, height: 20 }
        ],
        bombSites: [
            { name: 'A', x: 100, y: 200, width: 150, height: 150 },
            { name: 'B', x: 525, y: 600, width: 150, height: 150 },
            { name: 'C', x: 950, y: 200, width: 150, height: 150 }
        ]
    }
};

// Autres joueurs et données
let otherPlayers = {};
let bullets = [];
let particles = [];
let scoreboardVisible = false;
let buyMenuVisible = false;

// Initialisation du jeu
function initializeGame() {
    gameCanvas = document.getElementById('game-canvas');
    gameContext = gameCanvas.getContext('2d');
    minimapCanvas = document.getElementById('minimap-canvas');
    minimapContext = minimapCanvas.getContext('2d');
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    setupGameEventListeners();
    
    // Initialiser selon le mode de jeu
    initializeGameMode();
    
    startGameLoop();
    
    console.log('Jeu initialisé - Mode:', game.mode);
}

function initializeGameMode() {
    switch(game.mode) {
        case 'duel':
            initializeDuelMode();
            break;
        case 'competitive':
            initializeCompetitiveMode();
            break;
        case 'deathmatch':
            initializeDeathmatchMode();
            break;
    }
}

function initializeDuelMode() {
    game.roundTime = 100;
    game.buyTime = 30;
    game.maxRounds = 9; // Premier à 5
    spawnPlayer();
    startBuyPhase();
}

function initializeCompetitiveMode() {
    game.roundTime = 100;
    game.buyTime = 30;
    game.maxRounds = 25; // Premier à 13
    
    // Assigner la bombe à un attaquant aléatoire
    if (player.team === 'attackers') {
        assignBombToPlayer();
    }
    
    spawnPlayer();
    startBuyPhase();
}

function initializeDeathmatchMode() {
    game.roundTime = 600; // 10 minutes
    game.buyTime = 0;
    player.money = 9000; // Argent illimité
    spawnPlayer();
    game.phase = 'active';
}

// Gestion des phases de jeu
function startBuyPhase() {
    game.phase = 'buy';
    game.buyTime = 30;
    game.roundStartTime = Date.now();
    
    showMessage('Phase d\'achat - 30 secondes', 'info');
    
    // Ouvrir automatiquement le menu d'achat
    if (game.mode !== 'deathmatch') {
        openBuyMenu();
    }
    
    setTimeout(() => {
        startActivePhase();
    }, 30000);
}

function startActivePhase() {
    game.phase = 'active';
    game.roundTime = game.mode === 'deathmatch' ? 600 : 100;
    closeBuyMenu();
    
    showMessage('Round commencé !', 'success');
    
    // Réinitialiser les stats du round
    player.roundKills = 0;
    Object.values(otherPlayers).forEach(p => p.roundKills = 0);
}

function endRound(reason, winner) {
    game.phase = 'ended';
    
    // Calculer les récompenses
    calculateRoundRewards(reason, winner);
    
    // Mettre à jour le score
    if (winner === 'attackers') {
        game.attackersScore++;
    } else if (winner === 'defenders') {
        game.defendersScore++;
    }
    
    // Vérifier la fin de partie
    const maxScore = game.mode === 'duel' ? 5 : 13;
    if (game.attackersScore >= maxScore || game.defendersScore >= maxScore) {
        endMatch();
        return;
    }
    
    // Changement d'équipes à la mi-temps
    if (game.mode === 'competitive' && game.round === 13) {
        switchTeams();
        showMessage('Mi-temps ! Changement d\'équipes', 'info');
    }
    
    // Préparer le round suivant
    game.round++;
    setTimeout(() => {
        spawnAllPlayers();
        startBuyPhase();
    }, 5000);
}

function calculateRoundRewards(reason, winner) {
    const isWin = winner === player.team;
    let reward = 0;
    
    if (isWin) {
        reward = game.economy.winReward;
        // Reset loss streak
        game.economy.lossStreak[player.team] = 0;
    } else {
        // Loss bonus
        const lossStreak = game.economy.lossStreak[player.team];
        reward = game.economy.lossReward[Math.min(lossStreak, 2)];
        game.economy.lossStreak[player.team]++;
    }
    
    // Bonus pour les éliminations
    reward += player.roundKills * game.economy.killReward;
    
    // Bonus spéciaux
    if (reason === 'bomb_defused' && player.team === 'defenders') {
        reward += 300;
    }
    if (reason === 'bomb_exploded' && player.team === 'attackers') {
        reward += 300;
    }
    
    player.money += reward;
    
    showMessage(`+$${reward} (${isWin ? 'Victoire' : 'Défaite'})`, isWin ? 'success' : 'error');
}

// Système d'économie et menu d'achat
function openBuyMenu() {
    if (game.phase !== 'buy') return;
    
    buyMenuVisible = true;
    const buyMenu = createBuyMenu();
    document.body.appendChild(buyMenu);
}

function closeBuyMenu() {
    buyMenuVisible = false;
    const existingMenu = document.getElementById('buy-menu');
    if (existingMenu) {
        existingMenu.remove();
    }
}

function createBuyMenu() {
    const menu = document.createElement('div');
    menu.id = 'buy-menu';
    menu.className = 'buy-menu';
    menu.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(15, 20, 25, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 30px;
        z-index: 1000;
        max-width: 800px;
        max-height: 80vh;
        overflow-y: auto;
        backdrop-filter: blur(10px);
    `;
    
    menu.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="color: #00d4ff; margin: 0;">Boutique - $${player.money}</h2>
            <button onclick="closeBuyMenu()" style="background: rgba(255,255,255,0.1); border: none; color: white; padding: 8px 12px; border-radius: 6px; cursor: pointer;">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="buy-categories">
            ${createWeaponCategories()}
        </div>
        
        <div id="buy-weapons-grid" class="buy-weapons-grid">
            ${createWeaponGrid('pistols')}
        </div>
    `;
    
    return menu;
}

function createWeaponCategories() {
    const categories = ['pistols', 'smgs', 'rifles', 'snipers', 'shotguns', 'utility'];
    
    return categories.map(cat => `
        <button class="buy-category ${cat === 'pistols' ? 'active' : ''}" 
                onclick="switchBuyCategory('${cat}')" 
                style="padding: 10px 15px; margin: 5px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: white; cursor: pointer;">
            ${cat.charAt(0).toUpperCase() + cat.slice(1)}
        </button>
    `).join('');
}

function createWeaponGrid(category) {
    const categoryWeapons = weapons[category] || {};
    
    return Object.entries(categoryWeapons).map(([name, stats]) => {
        const canAfford = player.money >= stats.price;
        const isEquipped = player.equipped.includes(name);
        
        return `
            <div class="weapon-buy-card ${!canAfford ? 'disabled' : ''} ${isEquipped ? 'equipped' : ''}" 
                 onclick="${canAfford && !isEquipped ? `buyWeapon('${name}', ${stats.price})` : ''}"
                 style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); 
                        border-radius: 10px; padding: 15px; margin: 10px; cursor: ${canAfford && !isEquipped ? 'pointer' : 'not-allowed'};
                        opacity: ${canAfford ? '1' : '0.5'}; position: relative;">
                
                ${isEquipped ? '<div style="position: absolute; top: 5px; right: 5px; color: #4ade80;"><i class="fas fa-check"></i></div>' : ''}
                
                <div style="text-align: center;">
                    <h4 style="margin: 0 0 10px 0; color: white;">${name}</h4>
                    <div style="color: #00d4ff; font-weight: bold; font-size: 18px; margin-bottom: 10px;">$${stats.price}</div>
                    
                    ${stats.type !== 'armor' && stats.type !== 'spike' ? `
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px; font-size: 12px;">
                            <div>DMG: ${stats.damage}</div>
                            <div>ACC: ${stats.accuracy}%</div>
                            <div>FR: ${stats.fireRate}</div>
                            <div>PEN: ${stats.penetration}</div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }).join('');
}

function switchBuyCategory(category) {
    // Mettre à jour les boutons
    document.querySelectorAll('.buy-category').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Mettre à jour la grille
    document.getElementById('buy-weapons-grid').innerHTML = createWeaponGrid(category);
}

function buyWeapon(weaponName, price) {
    if (player.money < price) {
        showMessage('Pas assez d\'argent !', 'error');
        return;
    }
    
    const weaponStats = findWeaponStats(weaponName);
    if (!weaponStats) return;
    
    // Gérer les achats spéciaux
    if (weaponStats.type === 'armor') {
        player.armor = weaponStats.value;
        player.money -= price;
        showMessage(`Armure achetée (+${weaponStats.value})`, 'success');
        updateBuyMenu();
        return;
    }
    
    if (weaponStats.type === 'spike') {
        if (player.team !== 'attackers') {
            showMessage('Seuls les attaquants peuvent porter la spike', 'error');
            return;
        }
        game.bomb.carrier = currentUser.uid;
        showMessage('Spike équipée', 'success');
        return;
    }
    
    // Acheter une arme
    player.weapon = {
        name: weaponName,
        ammo: weaponStats.ammo,
        totalAmmo: weaponStats.totalAmmo,
        damage: weaponStats.damage,
        fireRate: weaponStats.fireRate,
        lastShot: 0,
        penetration: weaponStats.penetration,
        price: price
    };
    
    player.money -= price;
    player.equipped.push(weaponName);
    
    showMessage(`${weaponName} acheté !`, 'success');
    updateBuyMenu();
}

function findWeaponStats(weaponName) {
    for (const category of Object.values(weapons)) {
        if (category[weaponName]) {
            return category[weaponName];
        }
    }
    return null;
}

function updateBuyMenu() {
    const moneyDisplay = document.querySelector('.buy-menu h2');
    if (moneyDisplay) {
        moneyDisplay.textContent = `Boutique - $${player.money}`;
    }
    
    // Recréer la grille avec les nouveaux états
    const activeCategory = document.querySelector('.buy-category.active').textContent.toLowerCase();
    document.getElementById('buy-weapons-grid').innerHTML = createWeaponGrid(activeCategory);
}

// Gestion de la bombe
function assignBombToPlayer() {
    if (player.team === 'attackers') {
        game.bomb.carrier = currentUser.uid;
        showMessage('Vous portez la Spike !', 'info');
    }
}

function plantBomb() {
    if (game.bomb.carrier !== currentUser.uid) return;
    
    const currentMapData = maps[game.currentMap];
    const playerInSite = currentMapData.bombSites.find(site => 
        player.x >= site.x && player.x <= site.x + site.width &&
        player.y >= site.y && player.y <= site.y + site.height
    );
    
    if (!playerInSite) {
        showMessage('Vous devez être sur un site pour planter la spike', 'error');
        return;
    }
    
    // Commencer la plantation
    game.bomb.planting = true;
    showMessage('Plantation de la spike... (4s)', 'warning');
    
    setTimeout(() => {
        if (game.bomb.planting && player.alive) {
            game.bomb.planted = true;
            game.bomb.site = playerInSite.name;
            game.bomb.carrier = null;
            game.bomb.planting = false;
            game.bomb.timer = 45;
            
            showMessage(`Spike plantée sur le site ${playerInSite.name} !`, 'success');
            
            // Démarrer le timer de la bombe
            startBombTimer();
        }
    }, 4000);
}

function defuseBomb() {
    if (!game.bomb.planted || player.team !== 'defenders') return;
    
    const bombSite = maps[game.currentMap].bombSites.find(site => site.name === game.bomb.site);
    const nearBomb = Math.sqrt(
        Math.pow(player.x - (bombSite.x + bombSite.width/2), 2) +
        Math.pow(player.y - (bombSite.y + bombSite.height/2), 2)
    ) < 50;
    
    if (!nearBomb) {
        showMessage('Vous devez être près de la spike', 'error');
        return;
    }
    
    // Commencer le désamorçage
    game.bomb.defusing = true;
    showMessage('Désamorçage de la spike... (7s)', 'warning');
    
    setTimeout(() => {
        if (game.bomb.defusing && player.alive) {
            game.bomb.defused = true;
            game.bomb.defusing = false;
            
            showMessage('Spike désamorcée !', 'success');
            endRound('bomb_defused', 'defenders');
        }
    }, 7000);
}

function startBombTimer() {
    const bombInterval = setInterval(() => {
        if (!game.bomb.planted || game.bomb.defused) {
            clearInterval(bombInterval);
            return;
        }
        
        game.bomb.timer--;
        
        if (game.bomb.timer <= 0) {
            clearInterval(bombInterval);
            showMessage('La spike a explosé !', 'error');
            endRound('bomb_exploded', 'attackers');
        }
    }, 1000);
}

// Redimensionnement du canvas
function resizeCanvas() {
    const container = document.getElementById('game-screen');
    gameCanvas.width = container.clientWidth;
    gameCanvas.height = container.clientHeight;
}

// Configuration des contrôles
function setupGameEventListeners() {
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);
    
    gameCanvas.addEventListener('mousemove', handleMouseMove);
    gameCanvas.addEventListener('mousedown', handleMouseDown);
    gameCanvas.addEventListener('mouseup', handleMouseUp);
    gameCanvas.addEventListener('contextmenu', (e) => e.preventDefault());
    
    // Raccourcis spéciaux
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (buyMenuVisible) {
                closeBuyMenu();
            } else {
                toggleGameMenu();
            }
        }
        if (e.key === 'Tab') {
            e.preventDefault();
            showScoreboard();
        }
        if (e.key === 'b' || e.key === 'B') {
            if (game.phase === 'buy') {
                buyMenuVisible ? closeBuyMenu() : openBuyMenu();
            }
        }
    });
    
    document.addEventListener('keyup', (e) => {
        if (e.key === 'Tab') {
            e.preventDefault();
            hideScoreboard();
        }
    });
}

// Gestion des touches
function handleKeyDown(e) {
    keys[e.key.toLowerCase()] = true;
    
    switch(e.key.toLowerCase()) {
        case 'r':
            reloadWeapon();
            break;
        case 'e':
            interact();
            break;
        case 'g':
            dropWeapon();
            break;
        case '4':
            if (game.bomb.carrier === currentUser.uid && player.team === 'attackers') {
                plantBomb();
            } else if (game.bomb.planted && player.team === 'defenders') {
                defuseBomb();
            }
            break;
    }
}

function handleKeyUp(e) {
    keys[e.key.toLowerCase()] = false;
    
    // Arrêter les actions continues
    if (e.key === '4') {
        game.bomb.planting = false;
        game.bomb.defusing = false;
    }
}

// Gestion de la souris
function handleMouseMove(e) {
    const rect = gameCanvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
    
    const dx = mouse.x - player.x;
    const dy = mouse.y - player.y;
    player.angle = Math.atan2(dy, dx);
}

function handleMouseDown(e) {
    mouse.pressed = true;
    if (e.button === 0) shoot();
}

function handleMouseUp(e) {
    mouse.pressed = false;
}

// Spawn du joueur
function spawnPlayer() {
    const currentMapData = maps[game.currentMap];
    const spawnPoints = currentMapData.spawnPoints[player.team];
    const spawnPoint = spawnPoints[Math.floor(Math.random() * spawnPoints.length)];
    
    player.x = spawnPoint.x;
    player.y = spawnPoint.y;
    player.health = 100;
    player.alive = true;
    player.roundKills = 0;
    
    // Équipement de base
    if (game.mode === 'deathmatch') {
        player.money = 9000;
        player.armor = 50;
    }
}

function spawnAllPlayers() {
    spawnPlayer();
    // Respawn autres joueurs via Firebase
    if (game.matchId) {
        sendGameEvent(game.matchId, 'round_start', {
            round: game.round,
            team: player.team
        });
    }
}

// Boucle de jeu principale
function startGameLoop() {
    game.gameStarted = true;
    gameLoop = setInterval(() => {
        if (!game.gamePaused) {
            update();
            render();
        }
    }, 1000 / 60); // 60 FPS
}

// Mise à jour du jeu
function update() {
    if (!player.alive) return;
    
    updatePlayer();
    updateBullets();
    updateParticles();
    updateOtherPlayers();
    updateGameTimers();
    updateUI();
    
    // Synchronisation multijoueur
    if (game.matchId && currentUser) {
        updatePlayerPosition(game.matchId, player.x, player.y, player.angle);
    }
}

function updateGameTimers() {
    if (game.phase === 'buy' && game.buyTime > 0) {
        game.buyTime -= 1/60;
        if (game.buyTime <= 0) {
            startActivePhase();
        }
    }
    
    if (game.phase === 'active' && game.roundTime > 0) {
        game.roundTime -= 1/60;
        if (game.roundTime <= 0) {
            // Temps écoulé
            const winner = game.bomb.planted ? 'attackers' : 'defenders';
            endRound('time_up', winner);
        }
    }
}

// Mise à jour du joueur
function updatePlayer() {
    if (!player.alive) return;
    
    let deltaX = 0;
    let deltaY = 0;
    
    // Mouvement
    if (keys['z'] || keys['w']) deltaY -= player.speed;
    if (keys['s']) deltaY += player.speed;
    if (keys['q'] || keys['a']) deltaX -= player.speed;
    if (keys['d']) deltaX += player.speed;
    
    // Course (Shift)
    const isRunning = keys['shift'];
    const speedMultiplier = isRunning ? 1.5 : 1;
    deltaX *= speedMultiplier;
    deltaY *= speedMultiplier;
    
    // Accroupi (Ctrl) - améliore la précision
    const isCrouching = keys['control'];
    if (isCrouching) {
        deltaX *= 0.5;
        deltaY *= 0.5;
    }
    
    // Vérifier les collisions
    const newX = player.x + deltaX;
    const newY = player.y + deltaY;
    
    if (!checkWallCollision(newX, player.y)) {
        player.x = newX;
    }
    if (!checkWallCollision(player.x, newY)) {
        player.y = newY;
    }
    
    // Maintenir le joueur dans les limites
    player.x = Math.max(25, Math.min(gameCanvas.width - 25, player.x));
    player.y = Math.max(25, Math.min(gameCanvas.height - 25, player.y));
}

// Vérification des collisions avec les murs
function checkWallCollision(x, y) {
    const currentMapData = maps[game.currentMap];
    const playerRadius = 15;
    
    for (let wall of currentMapData.walls) {
        if (x + playerRadius > wall.x &&
            x - playerRadius < wall.x + wall.width &&
            y + playerRadius > wall.y &&
            y - playerRadius < wall.y + wall.height) {
            return true;
        }
    }
    return false;
}

// Tir avec système Valorant
function shoot() {
    if (!player.alive || game.phase !== 'active') return;
    
    const now = Date.now();
    const fireRateMs = 60000 / (player.weapon.fireRate * 60); // Conversion en ms
    
    if (now - player.weapon.lastShot < fireRateMs) return;
    if (player.weapon.ammo <= 0) return;
    
    player.weapon.lastShot = now;
    player.weapon.ammo--;
    
    // Calculer la précision avec spread
    const accuracy = player.weapon.accuracy / 100;
    const spread = (1 - accuracy) * 0.3; // Max spread de 0.3 radians
    const finalAngle = player.angle + (Math.random() - 0.5) * spread;
    
    // Créer le projectile
    const bullet = {
        x: player.x + Math.cos(player.angle) * 25,
        y: player.y + Math.sin(player.angle) * 25,
        dx: Math.cos(finalAngle) * 15,
        dy: Math.sin(finalAngle) * 15,
        damage: player.weapon.damage,
        penetration: player.weapon.penetration,
        owner: currentUser ? currentUser.uid : 'player',
        traveled: 0,
        maxDistance: 1000,
        weapon: player.weapon.name
    };
    
    bullets.push(bullet);
    
    // Effets
    createMuzzleFlash(player.x, player.y, player.angle);
    playSound('gunshot');
    
    // Envoyer l'événement multijoueur
    if (game.matchId) {
        sendGameEvent(game.matchId, 'shoot', {
            x: player.x,
            y: player.y,
            angle: finalAngle,
            weapon: player.weapon.name
        });
    }
    
    updateAmmoDisplay();
}

// Rechargement
function reloadWeapon() {
    if (player.weapon.ammo === player.weapon.totalAmmo) return;
    if (player.weapon.totalAmmo <= 0) return;
    
    const maxAmmo = findWeaponStats(player.weapon.name).ammo;
    const ammoNeeded = maxAmmo - player.weapon.ammo;
    const ammoToReload = Math.min(ammoNeeded, player.weapon.totalAmmo);
    
    player.weapon.ammo += ammoToReload;
    player.weapon.totalAmmo -= ammoToReload;
    
    updateAmmoDisplay();
    playSound('reload');
}

// Mise à jour des projectiles
function updateBullets() {
    bullets = bullets.filter(bullet => {
        bullet.x += bullet.dx;
        bullet.y += bullet.dy;
        bullet.traveled += Math.sqrt(bullet.dx * bullet.dx + bullet.dy * bullet.dy);
        
        if (bullet.traveled > bullet.maxDistance) return false;
        
        // Collision avec les murs
        if (checkWallCollision(bullet.x, bullet.y)) {
            createImpactEffect(bullet.x, bullet.y);
            return bullet.penetration-- > 1;
        }
        
        // Collision avec les joueurs
        for (let playerId in otherPlayers) {
            const otherPlayer = otherPlayers[playerId];
            const distance = Math.sqrt(
                Math.pow(bullet.x - otherPlayer.x, 2) + 
                Math.pow(bullet.y - otherPlayer.y, 2)
            );
            
            if (distance < 20 && otherPlayer.alive) {
                if (bullet.owner === (currentUser ? currentUser.uid : 'player')) {
                    handlePlayerHit(playerId, bullet);
                } else {
                    handlePlayerDamage(bullet.damage);
                }
                
                createBloodEffect(bullet.x, bullet.y);
                return bullet.penetration-- > 1;
            }
        }
        
        // Sortie de l'écran
        return !(bullet.x < 0 || bullet.x > gameCanvas.width || 
                bullet.y < 0 || bullet.y > gameCanvas.height);
    });
}

// Gestion d'un hit sur un joueur
function handlePlayerHit(targetPlayerId, bullet) {
    // Calculer les dégâts selon la zone touchée
    const isHeadshot = Math.random() < 0.25; // 25% de chance
    const damageMultiplier = isHeadshot ? 2 : 1;
    const finalDamage = bullet.damage * damageMultiplier;
    
    const isKill = finalDamage >= 100; // Simulation
    
    if (isKill) {
        player.roundKills++;
        showKillFeed(
            currentUser.displayName || 'Vous', 
            targetPlayerId, 
            bullet.weapon, 
            isHeadshot
        );
        
        // Vérifier si c'est un ace
        if (player.roundKills === 5) {
            showMessage('🏆 ACE!', 'success');
        }
    }
    
    // Envoyer l'événement de hit
    if (game.matchId) {
        sendGameEvent(game.matchId, 'hit', {
            targetId: targetPlayerId,
            damage: finalDamage,
            weapon: bullet.weapon,
            headshot: isHeadshot,
            kill: isKill
        });
    }
}

// Gestion des dégâts reçus
function handlePlayerDamage(damage) {
    // Réduction des dégâts par l'armure
    if (player.armor > 0) {
        const armorReduction = Math.min(damage * 0.7, player.armor);
        player.armor -= armorReduction;
        damage -= armorReduction;
    }
    
    player.health -= damage;
    
    if (player.health <= 0) {
        handlePlayerDeath();
    }
}

// Gestion de la mort du joueur
function handlePlayerDeath() {
    player.health = 0;
    player.alive = false;
    player.deaths++;
    
    showDeathScreen();
    
    // Vérifier si l'équipe est éliminée
    checkTeamElimination();
}

function checkTeamElimination() {
    // Compter les joueurs vivants de chaque équipe
    let aliveAttackers = 0;
    let aliveDefenders = 0;
    
    if (player.alive) {
        if (player.team === 'attackers') aliveAttackers++;
        else aliveDefenders++;
    }
    
    Object.values(otherPlayers).forEach(p => {
        if (p.alive) {
            if (p.team === 'attackers') aliveAttackers++;
            else aliveDefenders++;
        }
    });
    
    // Fin de round si une équipe est éliminée
    if (aliveAttackers === 0) {
        endRound('elimination', 'defenders');
    } else if (aliveDefenders === 0) {
        endRound('elimination', 'attackers');
    }
}

// Changement d'équipes
function switchTeams() {
    player.team = player.team === 'attackers' ? 'defenders' : 'attackers';
    
    // Réassigner la bombe si nécessaire
    if (player.team === 'attackers') {
        assignBombToPlayer();
    }
}

// Interactions
function interact() {
    // Ramasser des armes au sol
    // TODO: Implémenter le système d'armes au sol
}

function dropWeapon() {
    if (player.weapon.name === 'Classic') {
        showMessage('Impossible de jeter l\'arme de base', 'error');
        return;
    }
    
    // TODO: Implémenter le drop d'armes
    showMessage(`${player.weapon.name} jetée`, 'info');
}

// Mise à jour des particules (effets visuels)
function createMuzzleFlash(x, y, angle) {
    for (let i = 0; i < 5; i++) {
        particles.push({
            x: x + Math.cos(angle) * 30,
            y: y + Math.sin(angle) * 30,
            dx: Math.cos(angle + (Math.random() - 0.5) * 0.5) * (3 + Math.random() * 5),
            dy: Math.sin(angle + (Math.random() - 0.5) * 0.5) * (3 + Math.random() * 5),
            size: 2 + Math.random() * 3,
            color: `rgb(255, ${200 + Math.random() * 55}, 0)`,
            life: 10 + Math.random() * 10,
            maxLife: 10 + Math.random() * 10
        });
    }
}

function createImpactEffect(x, y) {
    for (let i = 0; i < 8; i++) {
        particles.push({
            x: x,
            y: y,
            dx: (Math.random() - 0.5) * 6,
            dy: (Math.random() - 0.5) * 6,
            size: 1 + Math.random() * 2,
            color: `rgb(${100 + Math.random() * 100}, ${100 + Math.random() * 100}, ${100 + Math.random() * 100})`,
            life: 20 + Math.random() * 20,
            maxLife: 20 + Math.random() * 20
        });
    }
}

function createBloodEffect(x, y) {
    for (let i = 0; i < 10; i++) {
        particles.push({
            x: x,
            y: y,
            dx: (Math.random() - 0.5) * 4,
            dy: (Math.random() - 0.5) * 4,
            size: 2 + Math.random() * 3,
            color: `rgb(${150 + Math.random() * 50}, 0, 0)`,
            life: 30 + Math.random() * 30,
            maxLife: 30 + Math.random() * 30
        });
    }
}

function updateParticles() {
    particles = particles.filter(particle => {
        particle.x += particle.dx;
        particle.y += particle.dy;
        particle.dx *= 0.98;
        particle.dy *= 0.98;
        particle.life--;
        return particle.life > 0;
    });
}

// Fonctions de rendu (render.js sera créé séparément)
function render() {
    // Effacer le canvas
    gameContext.fillStyle = '#1a1a1a';
    gameContext.fillRect(0, 0, gameCanvas.width, gameCanvas.height);
    
    renderMap();
    renderOtherPlayers();
    renderPlayer();
    renderBullets();
    renderParticles();
    renderBomb();
    renderMinimap();
}

function renderMap() {
    const currentMapData = maps[game.currentMap];
    
    // Dessiner les murs
    gameContext.fillStyle = '#444444';
    currentMapData.walls.forEach(wall => {
        gameContext.fillRect(wall.x, wall.y, wall.width, wall.height);
    });
    
    // Dessiner les sites de bombes
    currentMapData.bombSites.forEach(site => {
        gameContext.fillStyle = game.bomb.site === site.name ? 
            'rgba(255, 70, 85, 0.6)' : 'rgba(255, 70, 85, 0.3)';
        gameContext.fillRect(site.x, site.y, site.width, site.height);
        
        gameContext.fillStyle = '#ff4655';
        gameContext.font = '20px Arial';
        gameContext.textAlign = 'center';
        gameContext.fillText(
            `Site ${site.name}`, 
            site.x + site.width / 2, 
            site.y + site.height / 2
        );
    });
}

function renderPlayer() {
    if (!player.alive) return;
    
    gameContext.save();
    
    // Corps du joueur
    gameContext.fillStyle = player.team === 'attackers' ? '#ff4655' : '#00d4ff';
    gameContext.beginPath();
    gameContext.arc(player.x, player.y, 15, 0, Math.PI * 2);
    gameContext.fill();
    
    // Direction de visée
    gameContext.strokeStyle = '#ffffff';
    gameContext.lineWidth = 3;
    gameContext.beginPath();
    gameContext.moveTo(player.x, player.y);
    gameContext.lineTo(
        player.x + Math.cos(player.angle) * 25,
        player.y + Math.sin(player.angle) * 25
    );
    gameContext.stroke();
    
    // Indicateur de bombe
    if (game.bomb.carrier === currentUser.uid) {
        gameContext.fillStyle = '#ffd700';
        gameContext.beginPath();
        gameContext.arc(player.x, player.y - 25, 5, 0, Math.PI * 2);
        gameContext.fill();
    }
    
    gameContext.restore();
}

function renderBomb() {
    if (game.bomb.planted) {
        const bombSite = maps[game.currentMap].bombSites.find(site => site.name === game.bomb.site);
        if (bombSite) {
            const bombX = bombSite.x + bombSite.width / 2;
            const bombY = bombSite.y + bombSite.height / 2;
            
            // Bombe clignotante
            const blinkSpeed = Math.max(0.1, game.bomb.timer / 45);
            if (Math.sin(Date.now() * 0.01 / blinkSpeed) > 0) {
                gameContext.fillStyle = '#ff0000';
                gameContext.beginPath();
                gameContext.arc(bombX, bombY, 10, 0, Math.PI * 2);
                gameContext.fill();
            }
            
            // Timer de la bombe
            gameContext.fillStyle = '#ffffff';
            gameContext.font = '16px Arial';
            gameContext.textAlign = 'center';
            gameContext.fillText(
                `${Math.ceil(game.bomb.timer)}s`,
                bombX,
                bombY + 30
            );
        }
    }
}

function renderOtherPlayers() {
    Object.values(otherPlayers).forEach(otherPlayer => {
        if (!otherPlayer.alive) return;
        
        gameContext.save();
        
        gameContext.fillStyle = otherPlayer.team === 'attackers' ? '#ff4655' : '#00d4ff';
        gameContext.beginPath();
        gameContext.arc(otherPlayer.x, otherPlayer.y, 15, 0, Math.PI * 2);
        gameContext.fill();
        
        gameContext.strokeStyle = '#ffffff';
        gameContext.lineWidth = 2;
        gameContext.beginPath();
        gameContext.moveTo(otherPlayer.x, otherPlayer.y);
        gameContext.lineTo(
            otherPlayer.x + Math.cos(otherPlayer.angle || 0) * 25,
            otherPlayer.y + Math.sin(otherPlayer.angle || 0) * 25
        );
        gameContext.stroke();
        
        gameContext.restore();
    });
}

function renderBullets() {
    gameContext.fillStyle = '#ffff00';
    bullets.forEach(bullet => {
        gameContext.beginPath();
        gameContext.arc(bullet.x, bullet.y, 3, 0, Math.PI * 2);
        gameContext.fill();
    });
}

function renderParticles() {
    particles.forEach(particle => {
        const alpha = particle.life / particle.maxLife;
        gameContext.save();
        gameContext.globalAlpha = alpha;
        gameContext.fillStyle = particle.color;
        gameContext.beginPath();
        gameContext.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        gameContext.fill();
        gameContext.restore();
    });
}

function renderMinimap() {
    const scale = 0.15;
    
    minimapContext.fillStyle = '#000000';
    minimapContext.fillRect(0, 0, 150, 150);
    
    const currentMapData = maps[game.currentMap];
    minimapContext.fillStyle = '#444444';
    currentMapData.walls.forEach(wall => {
        minimapContext.fillRect(
            wall.x * scale, wall.y * scale, 
            wall.width * scale, wall.height * scale
        );
    });
    
    // Sites de bombes
    currentMapData.bombSites.forEach(site => {
        minimapContext.fillStyle = game.bomb.site === site.name ? '#ff0000' : '#ff4655';
        minimapContext.fillRect(
            site.x * scale, site.y * scale,
            site.width * scale, site.height * scale
        );
    });
    
    // Joueurs
    if (player.alive) {
        minimapContext.fillStyle = player.team === 'attackers' ? '#ff4655' : '#00d4ff';
        minimapContext.beginPath();
        minimapContext.arc(player.x * scale, player.y * scale, 3, 0, Math.PI * 2);
        minimapContext.fill();
    }
    
    Object.values(otherPlayers).forEach(otherPlayer => {
        if (otherPlayer.alive) {
            minimapContext.fillStyle = otherPlayer.team === 'attackers' ? '#ff4655' : '#00d4ff';
            minimapContext.beginPath();
            minimapContext.arc(otherPlayer.x * scale, otherPlayer.y * scale, 2, 0, Math.PI * 2);
            minimapContext.fill();
        }
    });
}

// Mise à jour de l'interface
function updateUI() {
    document.getElementById('player-health').textContent = Math.max(0, player.health);
    document.getElementById('player-armor').textContent = player.armor;
    document.getElementById('player-money').textContent = player.money;
    document.getElementById('attackers-score').textContent = game.attackersScore;
    document.getElementById('defenders-score').textContent = game.defendersScore;
    updateAmmoDisplay();
    updateTimerDisplay();
    updateBombDisplay();
}

function updateAmmoDisplay() {
    document.getElementById('current-ammo').textContent = player.weapon.ammo;
    document.getElementById('total-ammo').textContent = player.weapon.totalAmmo;
    document.getElementById('current-weapon').textContent = player.weapon.name;
}

function updateTimerDisplay() {
    let displayTime;
    
    if (game.phase === 'buy') {
        displayTime = Math.ceil(game.buyTime);
    } else if (game.phase === 'active') {
        displayTime = Math.ceil(game.roundTime);
    } else {
        displayTime = 0;
    }
    
    const minutes = Math.floor(displayTime / 60);
    const seconds = displayTime % 60;
    document.getElementById('round-timer').textContent = 
        `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

function updateBombDisplay() {
    const bombStatus = document.getElementById('bomb-status');
    if (!bombStatus) return;
    
    if (game.bomb.planted) {
        bombStatus.textContent = `Spike: ${Math.ceil(game.bomb.timer)}s`;
        bombStatus.style.color = game.bomb.timer <= 10 ? '#ff0000' : '#ffd700';
    } else if (game.bomb.carrier === currentUser.uid) {
        bombStatus.textContent = 'Spike portée';
        bombStatus.style.color = '#ffd700';
    } else {
        bombStatus.textContent = '';
    }
}

// Fonctions d'interface
function showKillFeed(killer, victim, weapon, headshot) {
    const killFeed = document.getElementById('kill-feed') || createKillFeed();
    
    const killEntry = document.createElement('div');
    killEntry.className = 'kill-entry';
    killEntry.style.cssText = `
        background: rgba(0, 0, 0, 0.8);
        padding: 8px 15px;
        margin-bottom: 5px;
        border-radius: 5px;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 10px;
    `;
    
    killEntry.innerHTML = `
        <span style="color: #00d4ff; font-weight: bold;">${killer}</span>
        <i class="fas fa-crosshairs" style="color: ${headshot ? '#ff4655' : '#ffffff'};"></i>
        <span style="color: #ffffff;">${weapon}</span>
        ${headshot ? '<i class="fas fa-bullseye" style="color: #ff4655;"></i>' : ''}
        <span style="color: #ef4444; font-weight: bold;">${victim}</span>
    `;
    
    killFeed.appendChild(killEntry);
    
    setTimeout(() => {
        if (killEntry.parentNode) {
            killEntry.remove();
        }
    }, 5000);
}

function createKillFeed() {
    const killFeed = document.createElement('div');
    killFeed.id = 'kill-feed';
    killFeed.style.cssText = `
        position: fixed;
        top: 20px;
        right: 200px;
        z-index: 150;
        pointer-events: none;
    `;
    document.body.appendChild(killFeed);
    return killFeed;
}

function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `game-message ${type}`;
    messageDiv.textContent = message;
    messageDiv.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 15px 30px;
        border-radius: 10px;
        font-size: 18px;
        font-weight: bold;
        z-index: 200;
        border: 2px solid ${type === 'success' ? '#4ade80' : type === 'error' ? '#ef4444' : '#00d4ff'};
    `;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 3000);
}

function showDeathScreen() {
    const deathScreen = document.createElement('div');
    deathScreen.id = 'death-screen';
    deathScreen.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 0, 0, 0.3);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 150;
        pointer-events: none;
    `;
    
    deathScreen.innerHTML = `
        <div style="text-align: center; color: white;">
            <h2 style="font-size: 48px; margin-bottom: 20px;">ÉLIMINÉ</h2>
            <p style="font-size: 18px;">Vous regardez vos coéquipiers...</p>
        </div>
    `;
    
    document.body.appendChild(deathScreen);
}

function hideDeathScreen() {
    const deathScreen = document.getElementById('death-screen');
    if (deathScreen) {
        deathScreen.remove();
    }
}

// Scoreboard
function showScoreboard() {
    const scoreboard = document.getElementById('scoreboard');
    if (scoreboard) {
        scoreboard.classList.remove('hidden');
        updateScoreboard();
    }
}

function hideScoreboard() {
    const scoreboard = document.getElementById('scoreboard');
    if (scoreboard) {
        scoreboard.classList.add('hidden');
    }
}

function updateScoreboard() {
    // TODO: Mettre à jour le scoreboard avec les stats des joueurs
}

// Gestion du menu de jeu
function toggleGameMenu() {
    const overlay = document.getElementById('game-menu-overlay');
    game.gamePaused = !game.gamePaused;
    
    if (game.gamePaused) {
        overlay.classList.remove('hidden');
    } else {
        overlay.classList.add('hidden');
    }
}

function resumeGame() {
    game.gamePaused = false;
    document.getElementById('game-menu-overlay').classList.add('hidden');
}

function leaveGame() {
    if (confirm('Êtes-vous sûr de vouloir quitter la partie ?')) {
        stopGame();
        showMainMenu();
    }
}

function stopGame() {
    if (gameLoop) {
        clearInterval(gameLoop);
        gameLoop = null;
    }
    
    game.gameStarted = false;
    cleanupRealtimeListeners();
    
    // Nettoyer les éléments d'interface
    const elements = ['kill-feed', 'death-screen', 'buy-menu'];
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.remove();
    });
}

function endMatch() {
    const won = (player.team === 'attackers' && game.attackersScore > game.defendersScore) ||
                 (player.team === 'defenders' && game.defendersScore > game.attackersScore);
    
    showMessage(won ? 'VICTOIRE !' : 'DÉFAITE !', won ? 'success' : 'error');
    
    // Sauvegarder les statistiques
    const matchResult = {
        mode: game.mode,
        map: game.currentMap,
        won: won,
        score: `${game.attackersScore}-${game.defendersScore}`,
        kills: player.kills,
        deaths: player.deaths,
        rounds: game.round
    };
    
    setTimeout(() => {
        stopGame();
        showMainMenu();
    }, 5000);
}

// Fonctions multijoueur (placeholders)
function updateOtherPlayers() {
    // Mise à jour via Firebase
}

function updateOtherPlayerPosition(playerId, playerData) {
    otherPlayers[playerId] = {
        ...otherPlayers[playerId],
        x: playerData.x,
        y: playerData.y,
        angle: playerData.angle,
        lastUpdate: Date.now()
    };
}

function handleGameEvent(event) {
    // Gérer les événements de jeu reçus
}

function playSound(soundName) {
    // Jouer les sons du jeu
    console.log(`🔊 Son: ${soundName}`);
}

// Export pour utilisation dans d'autres modules
window.GameEngine = {
    initializeGame,
    startGame: initializeGame,
    stopGame,
    endMatch,
    updateOtherPlayerPosition,
    handleGameEvent
};